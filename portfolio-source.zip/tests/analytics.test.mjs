import test from 'node:test';
import assert from 'node:assert/strict';
import {createAnalytics,clearAnalyticsCookies} from '../src/analytics.js';

function environment({host='alexaromina19-tech.github.io',path='/romina-pereyra-portfolio/',protocol='https:',referrer='',debugMode=false}={}){
  const scripts=[],cookieWrites=[];
  const win={location:{hostname:host,pathname:path,protocol}};
  let cookies='_ga=one; _ga_ABC123XYZ=two; _ga_OTHERPROPERTY=other; _gid=three; portfolio_consent=granted';
  const doc={referrer,head:{appendChild(script){scripts.push(script)}},createElement(tag){assert.equal(tag,'script');return {dataset:{},remove(){this.removed=true}}},get cookie(){return cookies},set cookie(value){cookieWrites.push(value)}};
  const tracker=createAnalytics({measurementId:'G-ABC123XYZ',debugMode,window:win,document:doc});
  const commands=()=>Array.from(win.dataLayer||[],entry=>Array.from(entry));
  const events=()=>commands().filter(entry=>entry[0]==='event');
  return {tracker,win,doc,scripts,cookieWrites,commands,events};
}

test('no Google loader or queue exists before consent, including after activity',()=>{
  const e=environment();
  e.tracker.page({route:'inicio'});
  e.tracker.event('contact_click',{source:'footer'});
  assert.equal(e.scripts.length,0);
  assert.equal(e.win.dataLayer,undefined);
  assert.equal(e.tracker.status().enabled,false);
});

test('local, incorrect host, unrelated path and insecure pages never collect',()=>{
  for(const options of [{host:'localhost'},{host:'127.0.0.1'},{host:'other.example'},{path:'/another-site/'},{protocol:'http:'}]){
    const e=environment(options);
    e.tracker.page({route:'proyecto/kubik'});
    e.tracker.setAllowed(true);
    assert.equal(e.scripts.length,0);
    assert.equal(e.events().length,0);
    assert.equal(e.tracker.status().eligible,false);
  }
});

test('late consent loads once and only reports the currently visible screen',()=>{
  const e=environment();
  e.tracker.page({route:'inicio'});
  e.tracker.page({route:'proyecto/kubik',title:'Kubik — Romina Pereyra',projectId:'kubik'});
  e.tracker.event('image_open',{project_id:'kubik',image_index:1});
  e.tracker.setAllowed(true);
  e.tracker.setAllowed(true);
  e.tracker.page({route:'proyecto/kubik',title:'Kubik — Romina Pereyra',projectId:'kubik'});
  assert.equal(e.scripts.length,1);
  assert.equal(e.events().length,1);
  assert.equal(e.events()[0][1],'page_view');
  assert.equal(e.events()[0][2].page_location,'https://alexaromina19-tech.github.io/romina-pereyra-portfolio/proyecto/kubik');
  assert.equal(e.events()[0][2].project_id,'kubik');
  const config=e.commands().find(entry=>entry[0]==='config')[2];
  assert.equal(config.send_page_view,false);
  assert.equal(config.allow_google_signals,false);
  assert.equal(config.allow_ad_personalization_signals,false);
  for(const command of e.commands().filter(entry=>entry[0]==='consent')){
    assert.equal(command[2].ad_storage,'denied');
    assert.equal(command[2].ad_user_data,'denied');
    assert.equal(command[2].ad_personalization,'denied');
  }
  assert.equal(e.commands()[0][2].analytics_storage,'denied');
});

test('SPA screens update referrer, dedupe StrictMode repeats and support return visits',()=>{
  const e=environment({referrer:'https://www.linkedin.com/feed/?token=private'});
  e.tracker.page({route:'inicio'});
  e.tracker.setAllowed(true);
  e.tracker.page({route:'inicio'});
  e.tracker.page({route:'info',title:'Sobre mí — Romina Pereyra'});
  e.tracker.page({route:'info',title:'Sobre mí — Romina Pereyra'});
  e.tracker.page({route:'inicio'});
  assert.equal(e.events().length,3);
  assert.equal(e.events()[0][2].page_referrer,'https://www.linkedin.com/feed/');
  assert.equal(e.events()[1][2].page_referrer,e.events()[0][2].page_location);
  assert.equal(e.events()[2][2].page_referrer,e.events()[1][2].page_location);
  assert.equal(JSON.stringify(e.events()).includes('private'),false);
});

test('query strings and unknown hash contents never become analytics page URLs',()=>{
  const e=environment();
  e.tracker.page({route:'info?email=private@example.com'});
  e.tracker.setAllowed(true);
  assert.equal(e.events()[0][2].page_location,'https://alexaromina19-tech.github.io/romina-pereyra-portfolio/inicio');
  e.tracker.page({route:'proyectos/Gr%C3%A1fico'});
  assert.equal(e.events()[1][2].page_location,'https://alexaromina19-tech.github.io/romina-pereyra-portfolio/proyectos');
});

test('revocation immediately disables GA, clears pending data and blocks every later event',()=>{
  const e=environment();
  e.tracker.page({route:'inicio'});
  e.tracker.setAllowed(true);
  assert.equal(e.tracker.event('contact_click',{source:'footer'}),true);
  e.tracker.setAllowed(false);
  assert.equal(e.win['ga-disable-G-ABC123XYZ'],true);
  assert.equal(e.scripts[0].removed,true);
  assert.equal(e.commands().length,0);
  e.tracker.page({route:'info'});
  assert.equal(e.tracker.event('portfolio_open',{source:'about'}),false);
  assert.equal(e.commands().length,0);
  assert.equal(e.cookieWrites.some(value=>value.startsWith('_ga=')),true);
  assert.equal(e.cookieWrites.some(value=>value.startsWith('portfolio_consent=')),false);
  assert.equal(e.cookieWrites.some(value=>value.startsWith('_ga_OTHERPROPERTY=')),false);
});

test('blocked loader fails safely and explicit off/on retries with current screen only',()=>{
  const e=environment();
  e.tracker.page({route:'inicio'});
  e.tracker.setAllowed(true);
  e.scripts[0].onerror();
  assert.equal(e.tracker.status().error,true);
  assert.equal(e.commands().length,0);
  e.tracker.page({route:'info'});
  assert.equal(e.events().length,0);
  e.tracker.setAllowed(false);
  e.tracker.setAllowed(true);
  assert.equal(e.scripts.length,2);
  assert.equal(e.events().length,1);
  assert.match(e.events()[0][2].page_location,/\/info$/);
});

test('changing permission after the library loaded reuses it without duplicate loaders or stale views',()=>{
  const e=environment();
  e.tracker.page({route:'inicio'});
  e.tracker.setAllowed(true);
  e.scripts[0].onload();
  assert.equal(e.tracker.status().loaded,true);
  e.tracker.setAllowed(false);
  e.tracker.page({route:'info'});
  e.tracker.setAllowed(true);
  assert.equal(e.scripts.length,1);
  assert.equal(e.events().length,1);
  assert.match(e.events()[0][2].page_location,/\/info$/);
  assert.equal(e.win['ga-disable-G-ABC123XYZ'],false);
});

test('automatic engagement defaults are query-free and update alongside every virtual screen',()=>{
  const e=environment();
  e.tracker.page({route:'inicio'});
  e.tracker.setAllowed(true);
  const initialCommands=e.commands();
  const firstContext=initialCommands.findIndex(entry=>entry[0]==='set'&&entry[1]?.page_location);
  const firstConfig=initialCommands.findIndex(entry=>entry[0]==='config');
  assert.ok(firstContext>=0&&firstContext<firstConfig);
  e.tracker.page({route:'proyecto/vitra',title:'Silla.05 — Romina Pereyra',projectId:'vitra'});
  const context=e.commands().filter(entry=>entry[0]==='set'&&entry[1]?.page_location).at(-1)[1];
  assert.equal(context.page_location,'https://alexaromina19-tech.github.io/romina-pereyra-portfolio/proyecto/vitra');
  assert.equal(context.page_title,'Silla.05 — Romina Pereyra');
  assert.equal(context.page_referrer,'https://alexaromina19-tech.github.io/romina-pereyra-portfolio/inicio');
});

test('only explicitly supported custom event fields are sent',()=>{
  const e=environment();
  e.tracker.setAllowed(true);
  assert.equal(e.tracker.event('contact_click',{source:'header',email:'private@example.com',message:'secret'}),true);
  assert.deepEqual(e.events()[0],['event','contact_click',{source:'header'}]);
  assert.equal(e.tracker.event('unknown_event',{anything:'secret'}),false);
});

test('cookie cleanup covers host and portfolio paths without affecting other cookies or parent domain',()=>{
  const e=environment();
  clearAnalyticsCookies({window:e.win,document:e.doc,measurementId:'G-ABC123XYZ'});
  assert.equal(e.cookieWrites.length,18);
  assert.equal(e.cookieWrites.some(value=>value.includes('Domain=github.io')),false);
  assert.equal(e.cookieWrites.every(value=>/^_(ga|gid)/.test(value)),true);
});

test('SSR and invalid configuration safely remain disabled',()=>{
  const tracker=createAnalytics();
  assert.doesNotThrow(()=>tracker.page({route:'info'}));
  assert.equal(tracker.setAllowed(true).enabled,false);
  assert.equal(tracker.event('contact_click'),false);
  assert.doesNotThrow(()=>tracker.destroy());
});

test('debug mode is absent for real visitors and enabled only by an explicit true option',()=>{
  for(const [debugMode,expected] of [[false,false],[undefined,false],['true',false],[true,true]]){
    const e=environment({debugMode});
    e.tracker.page({route:'inicio'});
    e.tracker.setAllowed(true);
    const config=e.commands().find(entry=>entry[0]==='config')[2];
    assert.equal('debug_mode' in config,expected);
    if(expected)assert.equal(config.debug_mode,true);
  }
});
