# Prototype Instructions

## User design decisions — 23 October 2026

- Use a black background, matching michomichi.com.
- Show the full name “Romina Pereyra” in one consistent typeface at any given moment. In the home hero, cycle automatically through distinct typefaces like the reference. Never split the name and surname into different families.
- Show all 17 projects on the home page, continuing in rows below Kubik, Nightfall and Kota Yamaji.
- On hover over each home card, show clear animated movement using real project views. Preserve keyboard access and reduced-motion preferences.
- Keep the original surname spelling from the portfolio: Pereyra.

Run the local server yourself and open the preview in the browser available to this environment. Do not give the user server-start instructions when you can run it.

Before making substantial visual changes, use the Product Design plugin's `get-context` skill when the visual source is unclear or no longer matches the current goal. When the user gives durable prototype-specific design feedback, preferences, or decisions, record them in `AGENTS.md`.

When implementing from a selected generated mock, treat that image as the source of truth for layout, component anatomy, density, spacing, color, typography, visible content, and hierarchy.

Build app UI in `src/`. Keep `.openai/hosting.json`, `worker/index.js`, `scripts/prepare-sites-build.mjs`, and `tests/sites-worker.test.mjs` intact so the same local prototype can be handed to Sites. Before a Sites handoff, run `npm run build` and `npm run test:sites`; the build must leave `dist/client/index.html`, `dist/server/index.js`, and `dist/.openai/hosting.json`.

## Project detail feedback — 23 October 2026

- Match all project cover titles to the original Drive PDF: exact serif/script lettering, scale, line arrangement and placement above the product. Preserve the whole cover canvas without cropping the product.
- Results show individual original images, without the white page margins of the PDF layout.
- Process shows only individual development images in an arrow-controlled carousel, with no PDF paragraphs or duplicated process description. Preserve swipe, keyboard navigation and reduced-motion preferences.
- Preserve the original PDF color appearance. Do not apply brightness or color filters to portfolio imagery.

## Homepage replacement — 24 October 2026

- The new homepage reference supersedes the earlier black homepage layout: https://lovable.dev/templates/websites/portfolio/parallax-artist-portfolio . Replace only the homepage with its light background and image parallax composition using Romina's own work.
- Retain the full-name font sequence, speed it up from 1200 ms, and keep both words in the same font at every step. Use only the full name for the primary hero title. Preserve the original document spelling Romina Pereyra.
- Keep all project detail corrections requested earlier. Do not redesign the other routes to match the new homepage.
- Implementation now exists locally in ParallaxHome.jsx / parallax-home.css, based on the template’s official screenshot and public styles/motion geometry. Browser QA and publication remain pending: the browser tool still reports disabled after a fresh reset. Do not claim public deployment or visual verification until confirmed.

## Results and process carousels — 24 October 2026

- Use horizontal carousels for both final images and process images on every project. Support previous/next arrows, mouse dragging, touch swiping and keyboard arrows.
- Show only individual original images, without PDF page backgrounds, white framing, visible result headings or PDF process paragraphs. Preserve complete images inside a landscape viewing area and allow each image to open enlarged.

## Current handoff state — 24 October 2026

- Local preview: http://127.0.0.1:4176/dist/client/ (Python retained server). Updated home, original covers, and both carousels are implemented; SSR checks pass for all 17 project routes, home, projects archive and info.
- GitHub connector currently authenticates as npb22. Its permissions on alexaromina19-tech/romina-pereyra-portfolio are pull:true, push:false. The requested GitHub Pages URL is still the previous deployment. Do not publish into another account or claim that local changes are live.
- The user has been asked to connect the GitHub plugin as alexaromina19-tech. Browser UI control also remains unavailable despite the user reporting it enabled.

## Accepted local design and refinements — 24 October 2026

- The user has viewed and approved the local homepage and general project pages. Keep the current parallax homepage and exact PDF cover lettering.
- Slightly accelerate the full-name font cycle from 650 to 580 ms.
- Archive heading must say only “Proyectos”; remove “seleccionados”.
- Increase breathing room above and below the detail-summary text on all 17 projects.
- Replace ONLY final-result carousels with fixed compositions following the source PDF photo arrangement. Keep black gaps with no white page background; subtle hover motion is acceptable. Preserve the process carousel.
- Improve photos to native original resolution and lossless output where appropriate. Compare actual colors against the original PDF; never add arbitrary saturation/contrast to compensate for perceived differences. Keep original colors and high quality throughout.

- Latest refinements are compiled and served locally: 580 ms name cycle, Proyectos heading without subtitle, expanded summary spacing, 17 fixed final-photo compositions using source PDF crops, process carousels preserved, native-resolution lossless sRGB images. Color audit: 222/222 exported detail images match source-render pixels exactly. User-facing preview can be refreshed with ?revision=3.

## Featured homepage photo — 24 October 2026

- Replace the prominent Grease dolls photograph in the parallax hero with the full front view of the IKEA Switch Seat bench (switch-seat-results-2.webp). Preserve the whole furniture and keep Chips Ahoy in its approved position.
- The browser session is now available and owns the GitHub repository. Use this existing authorized session to publish; the separate GitHub connector still uses npb22 and must not be used to write.

## Publication readiness — 24 October 2026

- Final browser QA passed on desktop and mobile after the mobile-only IKEA framing correction. Evidence: qa/final-browser-qa.json and design-qa.md. Source colors and native lossless exports remain verified.
- Upload static assets first through the authorized browser session, then activate the current app bundles/index/README and the editable source archive together. Avoid duplicate public media ZIP archives; the repository already contains the complete WebP assets. README explains how to combine those assets with portfolio-source.zip.

## Published baseline and latest refinements — 24 October 2026

- Baseline successfully published to https://alexaromina19-tech.github.io/romina-pereyra-portfolio/ at commit ddac47f11255f7389acb61aa21b40e8533f771cb. This supersedes the earlier notes about browser unavailability and pending publication.
- Keep the prominent horizontal IKEA bench in its current home position, but remove the props. Use the separately edited switch-seat-home-clean.webp only for this homepage slot; preserve the original photograph in the project detail.
- Remove the large workshop photograph and its caption from Info; retain all other information.
- Every final-result image should have a visible black separator, with consistent thickness. Keep the source composition; increase the hover lift slightly so it is clearer.
- Accelerate the full-name font cycle slightly from 580 to 540 ms; both words always share one family.
- Hablemos, Contacto, the visible email address and footer contact links should open Gmail's compose view addressed to alexaromina30@gmail.com in a new tab. Do not send a message.
- Recheck source PDF colors and quality against the actual page rendering; preserve original colors rather than adding arbitrary enhancement.

- Latest refinements successfully published and browser-verified at commit05f0190715f42f39116d52e7a68b4a1415c44d73, workflow40098232175. Evidence:qa/refinement-verification.json and qa/published-refinement-home.png. Source colors rechecked against PDF; no color adjustment made or justified.

## White theme and complete framing — latest 24 October 2026

- Latest user request supersedes black page background and process carousels: all UI surfaces should be white with black text, including projects, Info, menu and zoom. Preserve photograph colors and source cover-title artwork.
- Show full native images centered in every frame; use full native product photographs in the archive instead of pre-cropped thumbnails, with complete hero views when all final photographs are close-ups. Choose complete product views for home gallery and keep all12moving hero frames within the viewport. Scale whole frames on hover instead of zooming/cropping inside.
- Swap the prominent clean IKEA bench and Time Out in the moving first-screen composition; retain the clean horizontal bench, now separated from the other IKEA view. This is not a swap in the lower homepage project gallery.
- Full-name font cycle now420ms; preserve complete name and consistent typeface across both words.
- Final and process photographs are both fixed galleries, with visible headings Fotos finales and Proceso, a brief existing project-process description,24px gaps desktop/20px mobile,6px black borders and stronger hover lift/scale. No arrow carousel remains. All92final and130process images remain zoomable.

- White theme, complete framing and fixed process galleries published and browser-verified at commit a211a73cc4fdafa1924f767739f6d94a316e52f4; workflow 40117915440 succeeded. Public app: index-DauRMZN0.js / index-CHSNlqio.css. All 378 current build files match GitHub blobs. QA: qa/white-theme-verification.json.

## Focused editorial previews — latest request

- Keep white UI and original project detail covers/images. Remove visible Fotos finales heading and every black image border. Retain Proceso + brief text, fixed galleries and spacing; increase whole-frame hover to1.09/-20px.
- Home project gallery: show Vitra chair and IKEA chair-only as tight complete portrait compositions; remove the IKEA bench from the home preview. Zoom Grease to both complete doll boxes, removing excess dark background. Tighten Red Trackwear garment/sensor; Aurea2030 should use the cover portrait wearing the ear piece, vertical. Keep original pixels using safe CSS viewports where possible.
- Moving hero: preserve a clear central band for the whole animated name. No project image may intersect the name or contact area. Use consistent photo gutters and gentle depth/rotation, with complete frames inside screen.
- Archive: all17preview frames are the same horizontal16:10 shape, filled with matching photographic background. User explicitly authorizes ImageGen background extension where needed; preserve complete objects, actual design, colors and lettering. Use separate new *-archive-focus.webp assets, leaving original detail photos intact. Replace Moonlit front view with complete3/4cover view; Amics with the outdoor column photo. Give Trizart more room above; enlarge Grease, Vitra, IKEA and wearables within their frames.

- Focused editorial preview update published and browser-verified at commit 5183e30117396e823978747a1082f3e5b5220a46; workflow 40123259105 succeeded. Current app index-C69xNTda.js / index-UU1PmWfU.css. All 395 current build files match repository blobs. Twelve hero photos have zero title/contact intersections; all 17 archive previews are 16:10. Public final/process borders are 0px and visible Fotos finales heading is absent. Sources inside project details are unchanged. QA: qa/editorial-verification.json; ImageGen provenance: qa/preview-image-edits.json.

## Scattered homepage collage — latest feedback, 24 October 2026

- Supersede the two horizontal photo bands with an irregular collage distributed across the first screen. Balance the spaces between neighbours with a common gutter, retain varied orientations and complete product crops, and apply a slight 1.4px blur only to these moving hero photos. The lower home gallery stays sharp.
- The user now permits overlap behind the animated name, although less overlap is preferable. Keep the name above the collage and preserve the 420ms full-name font sequence.
- Mescladís in the hero uses the original blue pattern with a yellow circle (results-3); the lower home gallery uses the original blue placemat with the pasta plate (results-5).
- Latest La Rambla choice is the black poster pasted onto the textured column (results-3), replacing the white freestanding poster in the lower home gallery. This supersedes the earlier white-column selection.
- Keep Aurea's portrait, the archive and every detail image unchanged. All final/process images on all 17 projects remain borderless; retain their approved spacing, hover enlargement and zoom.

## Images appearing on scroll — latest feedback

- The user approves the current design. Add a clear, smooth, one-time entrance as each image comes into view while scrolling through the home project gallery and every project's final and process galleries.
- Stagger images entering together by 110ms, capped at 330ms. Use opacity and an independent upward translation so existing hover zoom/lift, image dimensions, native colors, borderless presentation and all content remain intact.
- Do not reveal images a full screen before they enter view. Reveal keyboard-focused images immediately; with reduced motion or without IntersectionObserver, show every image without entrance motion. Disconnect observers when switching routes.

## Strong arrival motion and sequential cover titles — latest feedback

- Supersede the subtle 42px fade. The user explicitly wants much more noticeable movement: each home-gallery photo and every final/process photo travels from the sides (100–220px) and below (150px), rotates 5 degrees and scales from .78 to its final size, with a small settling overshoot. Duration820ms; stagger90ms capped450ms. Share the start timeline across observer batches so successive scrolling events do not accidentally start photos together; keep a separate timeline for headings. Trigger once the static image slot reaches70% of the viewport height, rather than observing the moving image itself.
- The first-screen scattered photos also enter in a quick stagger. Keep their final positions, blur, crops and the420ms name typography cycle.
- Animate every project cover's exact original title in order: primary lettering first, script line second (Aurea has a third2030layer). Extract source PDF text layers without changing glyphs, placement or color. Wait for these images to load; after motion show the unchanged original full-title bitmap for exact final pixels.
- Reveal the project-summary title/subtitle and Proceso heading too. Keep the approved original photographs, spacing, borderless presentation, hover zoom and click enlargement.
- Rearm photos only after they have moved completely below the viewport, allowing another downward pass to animate again. Keep above-screen photos visible when scrolling back up. Clear finished animations, preserve immediate keyboard access and reduced-motion fallback, and clean up load listeners/observers/animation frames on route changes.

## Fixed calligraphy, professional role and animated archive — latest feedback

- Stop cycling home-name typefaces. Keep the whole original name Romina Pereyra in Pinyon calligraphy; bring it to the center with a single clear entrance, then leave it stationary.
- Under the name show “Diseñadora de producto · Diseño gráfico y editorial” in a lighter upright typeface, using the existing Bodoni face to complement the script and reference the project covers. Give this line a subsequent entrance and keep it clearly readable on desktop/mobile.
- The first-screen background photos should visibly enter one by one from different directions in sequence with the name. Wait for their pixels to load so the entrance is not spent before the photograph appears. Preserve the final collage positions, complete crops, blur and parallax.
- Apply the same strong, approved scroll arrival to all 17 cards on the separate Proyectos archive, including their captions. Observe static link slots and animate their child wrapper, preserving the current image hover lift, native landscape frames, keyboard access and category navigation.
- Everything below the home hero and inside project details is approved. Preserve it. Info keeps its existing static name styling.

## Sequential identity and animated About — 25 October 2026

- Home sequence is now strictly: finish all 12 background-photo entrances, then the calligraphic name, then the product-design field, then the graphic/editorial field. Unlock each phase from actual animation-end events, with 100ms between phases; keep the final composition unchanged. Reduced motion must show the complete content immediately.
- Animate the separate Proyectos page's main title, in addition to its already approved 17 card entrances.
- About should animate its name, biography paragraphs, location, CV columns and closing photograph as they enter view. Preserve the existing biography/CV wording and the Info name's upright font.
- Restore a large closing photo after the CV, using romina-proceso.webp: Romina with a protection screen/helmet and a tool. This supersedes the earlier removal of a workshop photo. Do not use romina-taller.webp (walking) or romina-retrato.webp (portrait). Display the complete native 1600×1133 image in black and white with a scoped grayscale filter, leaving the original source untouched.
- Let the CV breathe: 48px row gaps, extra bottom padding after the experience/Ormobook entry, generous space before the photo, and at least64px before the footer rule. Keep the complete photograph visible at its natural ratio on desktop/mobile.

## Immediate identity after the images — latest 25 October 2026

- In the home intro, reveal the name immediately after all 12 photographs are fully visible. Listen for their separate 320ms opacity entrances, without waiting for the 900ms travel to settle or inserting a pause. Keep the existing positions, photo stagger and movement. The name enters in600ms; the two design fields retain their separate subsequent entrances.
- On About, the name must enter first, before the eyebrow and biography. Unlock the remaining information only after its actual heading animation finishes, retaining the existing scroll entrances, CV spacing and black-and-white workshop photograph.

## Welding film homepage — 26 October 2026

- Replace only the first-screen scattered collage with the supplied welding film. Keep the lower 17-project homepage gallery and all other approved layouts. Use the native1280×720 clip, muted, looping, playsInline and1.35× faster (baked into the video), with a short cyclic dissolve. Use romina-welding-loop.mp4 and romina-welding-poster.webp.
- The person and workshop are monochrome; isolate the bright spark trails with a soft highlight matte and warm-gold color grade. Do not upscale or generate the person/video. Keep the original upload untouched. Processing provenance: qa/welding-video-processing.json and references/portfolio/prepare_welding_video.py.
- Keep the Pinyon calligraphy and sequential name→product→graphic/editorial entrances. The name is now vivid yellow #ffe03b, with softer golden-yellow secondary text #f4d57b over a restrained dark overlay. Start promptly once the poster/video and fonts are ready. Provide pause/play and respect reduced motion; pause when hidden or off screen.
- Time Out's MOCO advertisement uses time-out-results-5-complete.webp, the full native1348×1341 photograph from the PDF, with complete teal background and magazine. Preserve source colors/text; no generated background is needed.
- Key each Project component by its id so direct project-to-project navigation remounts the summary name/subtitle and replays their approved entrances, rather than reusing a settled heading.

## Homepage typography and controls — latest 26 October 2026

- Desktop name is larger in two Pinyon lines, within a left-hand pane ending before the person. Account for the video's centered cover crop at taller aspect ratios; keep the name clear of the person throughout its entrance.
- On mobile retain the existing single-line name size, and vertically center the whole name/role/contact group.
- Both name and role fields use exactly #ffe03b. Role fields now use Arial/Helvetica regular sans serif, stacked for a clear narrow-column layout. The source PDF's sans family is Elza; do not distribute commercial font files from its PDF subsets.
- Menu lines are explicit white inline SVG with a subtle dark circular backing, without blending them into the background. Play is a simple SVG triangle and pause uses two vector strokes; no emoji or text-glyph icons.
- Preserve the welding film, spark grade, sequential entrances, all project galleries and previous fixes.

## Single-line desktop identity and walking About photo — latest 26 October 2026

- The user explicitly requires the desktop full name on ONE horizontal line, and both role fields together on another horizontal line. This supersedes the two-line name and stacked desktop role layout. Keep Pinyon, Arial, #ffe03b and the existing entrance order; size the text to the left-side space available before the person, rather than crossing onto the person. Retain the centered mobile layout and its existing type size.
- Replace only the closing About photo with romina-taller.webp, the original cover photograph of Romina walking/standing in the workshop. Keep it large, complete, black and white, with its natural1600×1133 ratio and existing entrance animation. This supersedes the welding/photo selection; preserve all biography and CV content.

## Centered desktop CV — latest 26 October 2026

- On desktop above900px, center the About CV's formation, experience, tools and contact text. Constrain the CV container to the same1440px maximum width as the closing photograph, with automatic side margins. Preserve column proportions, all text, typography, spacing, animations, the photo and mobile/tablet layouts.


## Consent-based GA4 analytics — 26 October 2026

- User chose free Google Analytics 4. Account owner is Romina’s Google account alexaromina19@gmail.com; user accepted service/data-processing terms in the browser. Web stream 16205809746, measurement ID G-8MDXK7THSJ. ID is public configuration, never publish auth tokens.
- Preserve every approved visual layout. Add only a restrained consent banner and a permanent Privacy/cookies preferences control, also accessible on Home (its standard Footer is hidden).
- Basic consent mode: no Google script or analytics request before explicit acceptance; no collection after reject or browser exclusion. Keep all advertising consent denied, Google signals/personalization off. Only production host/path are eligible. On revocation disable immediately, clear this property’s GA cookies and reload to remove resident library listeners.
- Measure each hash route manually as a virtual page path (including every project) without duplicates. Google Enhanced Measurement is disabled to avoid automatic history/outbound/form events. Measure project views/time, image enlargements and explicit Drive/Gmail click events with fixed labels, never raw contact URLs, form contents, user IDs or arbitrary queries. Versions in ?v= must not split reports.
- Consent expires after180days, GA cookies limited to180days without extension. Browser exclusion is independent and persists until changed; enable it on the user’s browser after testing, and explain mobile/other browsers need it too. Statistics start after activation and only include consenting/nonblocked visits; Drive/Gmail activity after outbound navigation cannot be observed.
