# Prototype Instructions

## User design decisions — 23 October 2026

- Use a black background, matching michomichi.com.
- Show the full name “Romina Pereyra” in one consistent typeface at any given moment. In the home hero, cycle automatically through distinct typefaces like the reference. Never split the name and surname into different families.
- Show all 17 projects on the home page, continuing in rows below Kubik, Nightfall and Kota Yamaji.
- On hover over each home card, show clear animated movement using real project views. Preserve keyboard access and reduced-motion preferences.
- Keep the original surname spelling from the portfolio: Pereyra.

Run the local server yourself and open the preview in the browser available to this environment. Do not give the user server-start instructions when you can run it.

Before making substantial visual changes, use the Product Design plugin's `get-context` skill when the visual source is unclear or no longer matches the current goal. When the user gives durable prototype-specific design feedback, preferences, or decisions, record them in `AGENTS.md`.

When implementing from a selected generated mock, treat that image as the source of truth for layout, component anatomy, density, spacing, color, typography, visible content, and hierarchy.

Build app UI in `src/`. Keep `.openai/hosting.json`, `worker/index.js`, `scripts/prepare-sites-build.mjs`, and `tests/sites-worker.test.mjs` intact so the same local prototype can be handed to Sites. Before a Sites handoff, run `npm run build` and `npm run test:sites`; the build must leave `dist/client/index.html`, `dist/server/index.js`, and `dist/.openai/hosting.json`.

## Project detail feedback — 23 October 2026

- Match all project cover titles to the original Drive PDF: exact serif/script lettering, scale, line arrangement and placement above the product. Preserve the whole cover canvas without cropping the product.
- Results show individual original images, without the white page margins of the PDF layout.
- Process shows only individual development images in an arrow-controlled carousel, with no PDF paragraphs or duplicated process description. Preserve swipe, keyboard navigation and reduced-motion preferences.
- Preserve the original PDF color appearance. Do not apply brightness or color filters to portfolio imagery.

## Homepage replacement — 24 October 2026

- The new homepage reference supersedes the earlier black homepage layout: https://lovable.dev/templates/websites/portfolio/parallax-artist-portfolio . Replace only the homepage with its light background and image parallax composition using Romina's own work.
- Retain the full-name font sequence, speed it up from 1200 ms, and keep both words in the same font at every step. Use only the full name for the primary hero title. Preserve the original document spelling Romina Pereyra.
- Keep all project detail corrections requested earlier. Do not redesign the other routes to match the new homepage.
- Implementation now exists locally in ParallaxHome.jsx / parallax-home.css, based on the template’s official screenshot and public styles/motion geometry. Browser QA and publication remain pending: the browser tool still reports disabled after a fresh reset. Do not claim public deployment or visual verification until confirmed.

## Results and process carousels — 24 October 2026

- Use horizontal carousels for both final images and process images on every project. Support previous/next arrows, mouse dragging, touch swiping and keyboard arrows.
- Show only individual original images, without PDF page backgrounds, white framing, visible result headings or PDF process paragraphs. Preserve complete images inside a landscape viewing area and allow each image to open enlarged.

## Current handoff state — 24 October 2026

- Local preview: http://127.0.0.1:4176/dist/client/ (Python retained server). Updated home, original covers, and both carousels are implemented; SSR checks pass for all 17 project routes, home, projects archive and info.
- GitHub connector currently authenticates as npb22. Its permissions on alexaromina19-tech/romina-pereyra-portfolio are pull:true, push:false. The requested GitHub Pages URL is still the previous deployment. Do not publish into another account or claim that local changes are live.
- The user has been asked to connect the GitHub plugin as alexaromina19-tech. Browser UI control also remains unavailable despite the user reporting it enabled.

## Accepted local design and refinements — 24 October 2026

- The user has viewed and approved the local homepage and general project pages. Keep the current parallax homepage and exact PDF cover lettering.
- Slightly accelerate the full-name font cycle from 650 to 580 ms.
- Archive heading must say only “Proyectos”; remove “seleccionados”.
- Increase breathing room above and below the detail-summary text on all 17 projects.
- Replace ONLY final-result carousels with fixed compositions following the source PDF photo arrangement. Keep black gaps with no white page background; subtle hover motion is acceptable. Preserve the process carousel.
- Improve photos to native original resolution and lossless output where appropriate. Compare actual colors against the original PDF; never add arbitrary saturation/contrast to compensate for perceived differences. Keep original colors and high quality throughout.

- Latest refinements are compiled and served locally: 580 ms name cycle, Proyectos heading without subtitle, expanded summary spacing, 17 fixed final-photo compositions using source PDF crops, process carousels preserved, native-resolution lossless sRGB images. Color audit: 222/222 exported detail images match source-render pixels exactly. User-facing preview can be refreshed with ?revision=3.

## Featured homepage photo — 24 October 2026

- Replace the prominent Grease dolls photograph in the parallax hero with the full front view of the IKEA Switch Seat bench (switch-seat-results-2.webp). Preserve the whole furniture and keep Chips Ahoy in its approved position.
- The browser session is now available and owns the GitHub repository. Use this existing authorized session to publish; the separate GitHub connector still uses npb22 and must not be used to write.

## Publication readiness — 24 October 2026

- Final browser QA passed on desktop and mobile after the mobile-only IKEA framing correction. Evidence: qa/final-browser-qa.json and design-qa.md. Source colors and native lossless exports remain verified.
- Upload static assets first through the authorized browser session, then activate the current app bundles/index/README and the editable source archive together. Avoid duplicate public media ZIP archives; the repository already contains the complete WebP assets. README explains how to combine those assets with portfolio-source.zip.

## Published baseline and latest refinements — 24 October 2026

- Baseline successfully published to https://alexaromina19-tech.github.io/romina-pereyra-portfolio/ at commit ddac47f11255f7389acb61aa21b40e8533f771cb. This supersedes the earlier notes about browser unavailability and pending publication.
- Keep the prominent horizontal IKEA bench in its current home position, but remove the props. Use the separately edited switch-seat-home-clean.webp only for this homepage slot; preserve the original photograph in the project detail.
- Remove the large workshop photograph and its caption from Info; retain all other information.
- Every final-result image should have a visible black separator, with consistent thickness. Keep the source composition; increase the hover lift slightly so it is clearer.
- Accelerate the full-name font cycle slightly from 580 to 540 ms; both words always share one family.
- Hablemos, Contacto, the visible email address and footer contact links should open Gmail's compose view addressed to alexaromina30@gmail.com in a new tab. Do not send a message.
- Recheck source PDF colors and quality against the actual page rendering; preserve original colors rather than adding arbitrary enhancement.

- Latest refinements successfully published and browser-verified at commit05f0190715f42f39116d52e7a68b4a1415c44d73, workflow40098232175. Evidence:qa/refinement-verification.json and qa/published-refinement-home.png. Source colors rechecked against PDF; no color adjustment made or justified.

## White theme and complete framing — latest 24 October 2026

- Latest user request supersedes black page background and process carousels: all UI surfaces should be white with black text, including projects, Info, menu and zoom. Preserve photograph colors and source cover-title artwork.
- Show full native images centered in every frame; use full native product photographs in the archive instead of pre-cropped thumbnails, with complete hero views when all final photographs are close-ups. Choose complete product views for home gallery and keep all12moving hero frames within the viewport. Scale whole frames on hover instead of zooming/cropping inside.
- Swap the prominent clean IKEA bench and Time Out in the moving first-screen composition; retain the clean horizontal bench, now separated from the other IKEA view. This is not a swap in the lower homepage project gallery.
- Full-name font cycle now420ms; preserve complete name and consistent typeface across both words.
- Final and process photographs are both fixed galleries, with visible headings Fotos finales and Proceso, a brief existing project-process description,24px gaps desktop/20px mobile,6px black borders and stronger hover lift/scale. No arrow carousel remains. All92final and130process images remain zoomable.

- White theme, complete framing and fixed process galleries published and browser-verified at commit a211a73cc4fdafa1924f767739f6d94a316e52f4; workflow 40117915440 succeeded. Public app: index-DauRMZN0.js / index-CHSNlqio.css. All 378 current build files match GitHub blobs. QA: qa/white-theme-verification.json.

## Focused editorial previews — latest request

- Keep white UI and original project detail covers/images. Remove visible Fotos finales heading and every black image border. Retain Proceso + brief text, fixed galleries and spacing; increase whole-frame hover to1.09/-20px.
- Home project gallery: show Vitra chair and IKEA chair-only as tight complete portrait compositions; remove the IKEA bench from the home preview. Zoom Grease to both complete doll boxes, removing excess dark background. Tighten Red Trackwear garment/sensor; Aurea2030 should use the cover portrait wearing the ear piece, vertical. Keep original pixels using safe CSS viewports where possible.
- Moving hero: preserve a clear central band for the whole animated name. No project image may intersect the name or contact area. Use consistent photo gutters and gentle depth/rotation, with complete frames inside screen.
- Archive: all17preview frames are the same horizontal16:10 shape, filled with matching photographic background. User explicitly authorizes ImageGen background extension where needed; preserve complete objects, actual design, colors and lettering. Use separate new *-archive-focus.webp assets, leaving original detail photos intact. Replace Moonlit front view with complete3/4cover view; Amics with the outdoor column photo. Give Trizart more room above; enlarge Grease, Vitra, IKEA and wearables within their frames.

- Focused editorial preview update published and browser-verified at commit 5183e30117396e823978747a1082f3e5b5220a46; workflow 40123259105 succeeded. Current app index-C69xNTda.js / index-UU1PmWfU.css. All 395 current build files match repository blobs. Twelve hero photos have zero title/contact intersections; all 17 archive previews are 16:10. Public final/process borders are 0px and visible Fotos finales heading is absent. Sources inside project details are unchanged. QA: qa/editorial-verification.json; ImageGen provenance: qa/preview-image-edits.json.

## Scattered homepage collage — latest feedback, 24 October 2026

- Supersede the two horizontal photo bands with an irregular collage distributed across the first screen. Balance the spaces between neighbours with a common gutter, retain varied orientations and complete product crops, and apply a slight 1.4px blur only to these moving hero photos. The lower home gallery stays sharp.
- The user now permits overlap behind the animated name, although less overlap is preferable. Keep the name above the collage and preserve the 420ms full-name font sequence.
- Mescladís in the hero uses the original blue pattern with a yellow circle (results-3); the lower home gallery uses the original blue placemat with the pasta plate (results-5).
- Latest La Rambla choice is the black poster pasted onto the textured column (results-3), replacing the white freestanding poster in the lower home gallery. This supersedes the earlier white-column selection.
- Keep Aurea's portrait, the archive and every detail image unchanged. All final/process images on all 17 projects remain borderless; retain their approved spacing, hover enlargement and zoom.

## Images appearing on scroll — latest feedback

- The user approves the current design. Add a clear, smooth, one-time entrance as each image comes into view while scrolling through the home project gallery and every project's final and process galleries.
- Stagger images entering together by 110ms, capped at 330ms. Use opacity and an independent upward translation so existing hover zoom/lift, image dimensions, native colors, borderless presentation and all content remain intact.
- Do not reveal images a full screen before they enter view. Reveal keyboard-focused images immediately; with reduced motion or without IntersectionObserver, show every image without entrance motion. Disconnect observers when switching routes.
