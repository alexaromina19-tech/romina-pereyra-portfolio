# Prototype Instructions

## User design decisions — 23 October 2026

- Use a black background, matching michomichi.com.
- Show the full name “Romina Pereyra” in one consistent typeface at any given moment. In the home hero, cycle automatically through distinct typefaces like the reference. Never split the name and surname into different families.
- Show all 17 projects on the home page, continuing in rows below Kubik, Nightfall and Kota Yamaji.
- On hover over each home card, show clear animated movement using real project views. Preserve keyboard access and reduced-motion preferences.
- Keep the original surname spelling from the portfolio: Pereyra.

Run the local server yourself and open the preview in the browser available to this environment. Do not give the user server-start instructions when you can run it.

Before making substantial visual changes, use the Product Design plugin's `get-context` skill when the visual source is unclear or no longer matches the current goal. When the user gives durable prototype-specific design feedback, preferences, or decisions, record them in `AGENTS.md`.

When implementing from a selected generated mock, treat that image as the source of truth for layout, component anatomy, density, spacing, color, typography, visible content, and hierarchy.

Build app UI in `src/`. Keep `.openai/hosting.json`, `worker/index.js`, `scripts/prepare-sites-build.mjs`, and `tests/sites-worker.test.mjs` intact so the same local prototype can be handed to Sites. Before a Sites handoff, run `npm run build` and `npm run test:sites`; the build must leave `dist/client/index.html`, `dist/server/index.js`, and `dist/.openai/hosting.json`.

## Project detail feedback — 23 October 2026

- Match all project cover titles to the original Drive PDF: exact serif/script lettering, scale, line arrangement and placement above the product. Preserve the whole cover canvas without cropping the product.
- Results show individual original images, without the white page margins of the PDF layout.
- Process shows only individual development images in an arrow-controlled carousel, with no PDF paragraphs or duplicated process description. Preserve swipe, keyboard navigation and reduced-motion preferences.
- Preserve the original PDF color appearance. Do not apply brightness or color filters to portfolio imagery.

## Homepage replacement — 24 October 2026

- The new homepage reference supersedes the earlier black homepage layout: https://lovable.dev/templates/websites/portfolio/parallax-artist-portfolio . Replace only the homepage with its light background and image parallax composition using Romina's own work.
- Retain the full-name font sequence, speed it up from 1200 ms, and keep both words in the same font at every step. Use only the full name for the primary hero title. Preserve the original document spelling Romina Pereyra.
- Keep all project detail corrections requested earlier. Do not redesign the other routes to match the new homepage.
- Implementation now exists locally in ParallaxHome.jsx / parallax-home.css, based on the template’s official screenshot and public styles/motion geometry. Browser QA and publication remain pending: the browser tool still reports disabled after a fresh reset. Do not claim public deployment or visual verification until confirmed.

## Results and process carousels — 24 October 2026

- Use horizontal carousels for both final images and process images on every project. Support previous/next arrows, mouse dragging, touch swiping and keyboard arrows.
- Show only individual original images, without PDF page backgrounds, white framing, visible result headings or PDF process paragraphs. Preserve complete images inside a landscape viewing area and allow each image to open enlarged.

## Current handoff state — 24 October 2026

- Local preview: http://127.0.0.1:4176/dist/client/ (Python retained server). Updated home, original covers, and both carousels are implemented; SSR checks pass for all 17 project routes, home, projects archive and info.
- GitHub connector currently authenticates as npb22. Its permissions on alexaromina19-tech/romina-pereyra-portfolio are pull:true, push:false. The requested GitHub Pages URL is still the previous deployment. Do not publish into another account or claim that local changes are live.
- The user has been asked to connect the GitHub plugin as alexaromina19-tech. Browser UI control also remains unavailable despite the user reporting it enabled.

## Accepted local design and refinements — 24 October 2026

- The user has viewed and approved the local homepage and general project pages. Keep the current parallax homepage and exact PDF cover lettering.
- Slightly accelerate the full-name font cycle from 650 to 580 ms.
- Archive heading must say only “Proyectos”; remove “seleccionados”.
- Increase breathing room above and below the detail-summary text on all 17 projects.
- Replace ONLY final-result carousels with fixed compositions following the source PDF photo arrangement. Keep black gaps with no white page background; subtle hover motion is acceptable. Preserve the process carousel.
- Improve photos to native original resolution and lossless output where appropriate. Compare actual colors against the original PDF; never add arbitrary saturation/contrast to compensate for perceived differences. Keep original colors and high quality throughout.

- Latest refinements are compiled and served locally: 580 ms name cycle, Proyectos heading without subtitle, expanded summary spacing, 17 fixed final-photo compositions using source PDF crops, process carousels preserved, native-resolution lossless sRGB images. Color audit: 222/222 exported detail images match source-render pixels exactly. User-facing preview can be refreshed with ?revision=3.

## Featured homepage photo — 24 October 2026

- Replace the prominent Grease dolls photograph in the parallax hero with the full front view of the IKEA Switch Seat bench (switch-seat-results-2.webp). Preserve the whole furniture and keep Chips Ahoy in its approved position.
- The browser session is now available and owns the GitHub repository. Use this existing authorized session to publish; the separate GitHub connector still uses npb22 and must not be used to write.

## Publication readiness — 24 October 2026

- Final browser QA passed on desktop and mobile after the mobile-only IKEA framing correction. Evidence: qa/final-browser-qa.json and design-qa.md. Source colors and native lossless exports remain verified.
- Upload static assets first through the authorized browser session, then activate the current app bundles/index/README and the editable source archive together. Avoid duplicate public media ZIP archives; the repository already contains the complete WebP assets. README explains how to combine those assets with portfolio-source.zip.
