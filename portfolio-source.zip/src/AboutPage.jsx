import {useRef} from 'react';
import useScrollReveal from './useScrollReveal.js';

function RevealText({as:Tag='p',className,children}){
  return <Tag className={className} data-scroll-reveal="" data-reveal-kind="heading"><span className="scroll-reveal-content">{children}</span></Tag>;
}

export default function AboutPage({Name,contactHref,portfolioUrl}){
  const page=useRef(null);
  useScrollReveal(page);
  return <div ref={page} className="info-page">
    <section className="about-intro page-pad">
      <RevealText className="eyebrow">[UN POCO SOBRE MÍ]</RevealText>
      <RevealText as="h1"><Name/></RevealText>
      <div className="about-copy">
        <RevealText>Mi nombre es Romina Pereyra Bonija.<br/>Soy diseñadora de producto, gráfica y editorial.</RevealText>
        <RevealText>Aunque actualmente mi trabajo se centra sobre todo en el diseño de producto, también tengo formación en diseño gráfico y editorial, dos ámbitos que me interesan por su capacidad para construir imagen, narrativa y comunicación visual.</RevealText>
        <RevealText>Me atraen especialmente los proyectos donde el diseño se relaciona con el entorno audiovisual y el cine. Trabajo de forma directa, combinando investigación, prototipado y prueba, cuidando siempre la materialidad, la funcionalidad y el detalle.</RevealText>
        <RevealText className="about-location">Barcelona, España.</RevealText>
      </div>
    </section>
    <section className="cv-grid page-pad" aria-label="Currículum">
      <div data-scroll-reveal="" data-reveal-kind="heading"><div className="scroll-reveal-content">
        <h2>[FORMACIÓN]</h2>
        <p>ELISAVA, Barcelona<br/><span>Diseño e Ingeniería<br/>2023 — actualidad</span></p>
        <p>IFP Antoni Algueró<br/><span>Diseño y Edición de Publicaciones<br/>Impresas y Multimedia / 2021 — 2023</span></p>
      </div></div>
      <div data-scroll-reveal="" data-reveal-kind="heading"><div className="scroll-reveal-content">
        <h2>[EXPERIENCIA]</h2>
        <p>Museu del Disseny — DHUB<br/><span>Investigación en diseño y archivo / 2025</span></p>
        <p>OFFF Festival<br/><span>Apoyo logístico / 2024</span></p>
        <p>Graó Tècnic<br/><span>Diseño gráfico e identidad / 2023</span></p>
        <p>Editorial Ormobook<br/><span>Asistente de edición / 2022</span></p>
      </div></div>
      <div data-scroll-reveal="" data-reveal-kind="heading"><div className="scroll-reveal-content">
        <h2>[HERRAMIENTAS]</h2>
        <p>Illustrator · Photoshop · InDesign<br/>Rhinoceros 3D · Fusion 360<br/>Blender · AutoCAD · Figma</p>
        <h2 className="cv-subhead">[IDIOMAS]</h2>
        <p>Castellano — lengua materna<br/>Catalán — avanzado<br/>Inglés — elemental</p>
      </div></div>
      <div data-scroll-reveal="" data-reveal-kind="heading"><div className="scroll-reveal-content">
        <h2>[CONTACTO]</h2>
        <p><a href={contactHref} target="_blank" rel="noreferrer">alexaromina30@gmail.com</a></p>
        <p>Barcelona, España</p>
        <a className="underlined" href={portfolioUrl} target="_blank" rel="noreferrer">Ver portfolio original &gt;</a>
      </div></div>
    </section>
    <figure className="about-workshop page-pad" data-scroll-reveal="">
      <div className="scroll-reveal-content"><img src={import.meta.env.BASE_URL+'romina-proceso.webp?v=20261025-native'} alt="Romina Pereyra trabajando en el taller con pantalla de protección y una herramienta" width="1600" height="1133" loading="lazy" decoding="async"/></div>
    </figure>
  </div>;
}
