import {useCallback,useEffect,useRef} from 'react';
import {createAnalytics} from './analytics.js';
import config from './analytics-config.json';

// One tracker per document: StrictMode must not add a second tag or page view.
let tracker;
function analytics(){
  if(typeof window==='undefined')return null;
  return tracker||(tracker=createAnalytics({...config,debugMode:new URLSearchParams(window.location.search).get('analytics_debug')==='1'}));
}

export function trackAnalyticsEvent(name,parameters){
  return analytics()?.event(name,parameters)||false;
}

export default function usePortfolioAnalytics(screen){
  const current=useRef(screen);
  current.current=screen;
  const onPreferenceChange=useCallback(({consent,excluded})=>{
    const instance=analytics();
    if(!instance)return;
    const before=instance.status();
    const allowed=consent==='granted'&&!excluded;
    // Before permission, page() only remembers this screen; it sends nothing.
    if(allowed)instance.page(current.current);
    instance.setAllowed(allowed);
    if(!allowed&&(before.loaded||before.loading)){
      // Unload any Google timers/listeners too, so rejection sends no pings.
      window.location.reload();
    }
  },[]);

  useEffect(()=>{analytics()?.page(screen)},[screen.route,screen.title,screen.projectId]);
  useEffect(()=>{
    const click=event=>{
      const link=event.target.closest?.('a[href]');
      if(!link)return;
      let url;
      try{url=new URL(link.href,window.location.href)}catch{return}
      const source=current.current.route;
      if(url.hostname==='drive.google.com'&&url.pathname==='/file/d/1Vvenp56weMOv1ttr9H92sPPOcrgmMfM0/view'){
        trackAnalyticsEvent('portfolio_open',{source,link_destination:'drive_portfolio'});
      }else if(url.hostname==='mail.google.com'&&url.searchParams.get('view')==='cm'){
        trackAnalyticsEvent('contact_click',{source,link_destination:'gmail_compose'});
      }else if(url.origin===window.location.origin&&url.hash.startsWith('#proyectos/')){
        trackAnalyticsEvent('project_filter',{source:decodeURIComponent(url.hash.slice(1))});
      }
    };
    document.addEventListener('click',click);
    return()=>document.removeEventListener('click',click);
  },[]);
  return onPreferenceChange;
}
