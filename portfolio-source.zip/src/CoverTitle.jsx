import {useEffect,useRef,useState} from 'react';
import coverLayouts from './cover-layouts.json';
import coverLines from './cover-title-lines.json';

const image=file=>import.meta.env.BASE_URL+file+'?v=20261024-title-motion';

function CoverTitleArtwork({project}){
  const title=useRef(null);
  const [ready,setReady]=useState(false),[fallback,setFallback]=useState(false),[settled,setSettled]=useState(false);
  const layout=coverLayouts[project.id],layers=coverLines[project.id];
  useEffect(()=>{
    let cancelled=false;
    const cleanups=[];
    const decoded=async img=>{
      if(!img.complete)await new Promise(resolve=>{
        const done=()=>{img.removeEventListener('load',done);img.removeEventListener('error',done);resolve()};
        img.addEventListener('load',done);img.addEventListener('error',done);
        cleanups.push(()=>{img.removeEventListener('load',done);img.removeEventListener('error',done)});
      });
      if(!img.naturalWidth)return false;
      if(img.decode)try{await img.decode()}catch{return false}
      return true;
    };
    Promise.all([...title.current.querySelectorAll('[data-cover-line] img')].map(decoded)).then(results=>{
      if(cancelled)return;
      setFallback(results.some(result=>!result));setReady(true);
    });
    return()=>{cancelled=true;cleanups.forEach(cleanup=>cleanup())};
  },[]);
  return <h1 ref={title} className="detail-title" data-ready={ready} data-fallback={fallback} data-settled={settled} style={{...layout.overlayStyle,aspectRatio:layout.width+'/'+layout.height}}>
    <span className="visually-hidden">{project.title} — {project.subtitle}</span>
    <img className="cover-title-original" src={image(layout.titleImage)} alt="" aria-hidden="true" width={layout.width} height={layout.height} loading="eager" fetchPriority="high"/>
    {layers.map((layer,index)=><span className="cover-title-line" data-cover-line="" style={{'--line-index':index}} aria-hidden="true" key={layer.file} onAnimationEnd={event=>{if(index===layers.length-1&&event.target===event.currentTarget)setSettled(true)}}><img src={image(layer.file)} alt="" width={layer.width} height={layer.height} loading="eager" fetchPriority="high" decoding="async"/></span>)}
  </h1>;
}

export default function CoverTitle({project}){
  return <CoverTitleArtwork key={project.id} project={project}/>;
}
