import {useEffect} from 'react';
import './scroll-reveal.css';

export default function useScrollReveal(container,revision=''){
  useEffect(()=>{
    const root=container.current;
    if(!root)return;
    const items=[...root.querySelectorAll('[data-scroll-reveal]')];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    let observer,rearm,frame=0,enabled=false;
    const queue=new Set(),inView=new Set(),cleanups=[];
    const showImmediately=item=>{
      item.style.setProperty('--reveal-delay','0ms');
      item.dataset.revealState='instant';
      queue.delete(item);
    };
    const enqueue=item=>{
      if(!enabled||!inView.has(item)||item.dataset.revealState!=='pending'||item._revealWaiting)return;
      queue.add(item);
      if(frame)return;
      frame=requestAnimationFrame(()=>{
        frame=0;
        [...queue].filter(element=>inView.has(element)&&element.dataset.revealState==='pending').sort((a,b)=>{
          const ar=a.getBoundingClientRect(),br=b.getBoundingClientRect();return ar.top-br.top||ar.left-br.left;
        }).forEach((element,index)=>{
          element.style.setProperty('--reveal-delay',Math.min(index,3)*90+'ms');
          element.dataset.revealState='visible';
        });
        queue.clear();
      });
    };
    items.forEach((item,index)=>{
      item.style.setProperty('--arrival-x',index%2?'clamp(100px,16vw,220px)':'clamp(-220px,-16vw,-100px)');
      item.style.setProperty('--arrival-turn',index%2?'5deg':'-5deg');
      const loading=new Set([...item.querySelectorAll('img')].filter(img=>!img.complete));
      item._revealWaiting=loading.size>0;
      loading.forEach(img=>{
        const loaded=()=>{loading.delete(img);item._revealWaiting=loading.size>0;if(!loading.size)enqueue(item)};
        img.addEventListener('load',loaded,{once:true});img.addEventListener('error',loaded,{once:true});
        cleanups.push(()=>{img.removeEventListener('load',loaded);img.removeEventListener('error',loaded)});
        if(img.complete)loaded();
      });
    });
    const start=()=>{
      observer?.disconnect();rearm?.disconnect();cancelAnimationFrame(frame);frame=0;queue.clear();inView.clear();
      enabled=!reduced.matches&&'IntersectionObserver' in window;
      if(!enabled){
        items.forEach(showImmediately);
        return;
      }
      const waiting=items.filter(item=>!['visible','settled','instant'].includes(item.dataset.revealState));
      waiting.forEach(item=>{item.dataset.revealState='pending'});
      observer=new IntersectionObserver(entries=>{
        entries.forEach(entry=>{if(entry.isIntersecting){inView.add(entry.target);enqueue(entry.target)}else{inView.delete(entry.target);queue.delete(entry.target)}});
      },{rootMargin:'0px 0px -'+Math.round(innerHeight*.3)+'px 0px',threshold:0});
      // Replay on the next downward pass only after a photo has left well below view.
      rearm=new IntersectionObserver(entries=>entries.forEach(entry=>{
        if(!entry.isIntersecting&&entry.boundingClientRect.top>innerHeight+140&&['visible','settled'].includes(entry.target.dataset.revealState))entry.target.dataset.revealState='pending';
      }),{rootMargin:'160px 0px 160px 0px',threshold:0});
      items.forEach(item=>{observer.observe(item);rearm.observe(item)});
    };
    const focus=event=>{
      const item=event.target.closest('[data-scroll-reveal]');
      if(item&&root.contains(item))showImmediately(item);
    };
    const settle=event=>{
      if(!event.target.classList.contains('scroll-reveal-content'))return;
      const item=event.target.closest('[data-scroll-reveal]');
      if(item?.dataset.revealState==='visible')item.dataset.revealState='settled';
    };
    root.addEventListener('focusin',focus);
    root.addEventListener('animationend',settle);
    reduced.addEventListener('change',start);
    start();
    return()=>{enabled=false;observer?.disconnect();rearm?.disconnect();cancelAnimationFrame(frame);queue.clear();cleanups.forEach(cleanup=>cleanup());items.forEach(item=>{delete item._revealWaiting});root.removeEventListener('focusin',focus);root.removeEventListener('animationend',settle);reduced.removeEventListener('change',start)};
  },[container,revision]);
}
