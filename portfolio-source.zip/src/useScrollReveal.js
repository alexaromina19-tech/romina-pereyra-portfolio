import {useEffect} from 'react';
import './scroll-reveal.css';

export default function useScrollReveal(container,revision=''){
  useEffect(()=>{
    const root=container.current;
    if(!root)return;
    const items=[...root.querySelectorAll('[data-scroll-reveal]')];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    let observer;
    const showImmediately=item=>{
      item.style.setProperty('--reveal-delay','0ms');
      item.dataset.revealState='instant';
      observer?.unobserve(item);
    };
    const start=()=>{
      observer?.disconnect();
      if(reduced.matches||!('IntersectionObserver' in window)){
        items.forEach(showImmediately);
        return;
      }
      const waiting=items.filter(item=>!['visible','instant'].includes(item.dataset.revealState));
      waiting.forEach(item=>{item.dataset.revealState='pending'});
      observer=new IntersectionObserver(entries=>{
        const entering=entries.filter(entry=>entry.isIntersecting).sort((a,b)=>a.boundingClientRect.top-b.boundingClientRect.top||a.boundingClientRect.left-b.boundingClientRect.left);
        entering.forEach((entry,index)=>{
          entry.target.style.setProperty('--reveal-delay',Math.min(index,3)*110+'ms');
          entry.target.dataset.revealState='visible';
          observer.unobserve(entry.target);
        });
      },{rootMargin:'0px 0px -8% 0px',threshold:0});
      waiting.forEach(item=>observer.observe(item));
    };
    const focus=event=>{
      const item=event.target.closest('[data-scroll-reveal]');
      if(item&&root.contains(item))showImmediately(item);
    };
    root.addEventListener('focusin',focus);
    reduced.addEventListener('change',start);
    start();
    return()=>{observer?.disconnect();root.removeEventListener('focusin',focus);reduced.removeEventListener('change',start)};
  },[container,revision]);
}
