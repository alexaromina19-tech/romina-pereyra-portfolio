import {useEffect,useRef,useState} from 'react';
import projects from './projects.json';
import detailAssets from './detail-assets.json';
import {contactHref as mail} from './contact.js';
import {projectPreview} from './project-previews.js';
import PreviewImage from './PreviewImage.jsx';
import './parallax-home.css';

const image=file=>import.meta.env.BASE_URL+file+'?v=20261024-native';
// Two photo bands reserve a clear, stable space for the animated name.
const heroIds=['kubik','marshall','kota-yamaji','switch-seat','nightfall','chips-ahoy','time-out','aurea','silla-05','trofeo','mescladis','moonlit'];
const heroPhotos=heroIds.map(id=>projectPreview(projects.find(project=>project.id===id),'home'));
const order=['kubik','nightfall','kota-yamaji',...projects.filter(p=>!['kubik','nightfall','kota-yamaji'].includes(p.id)).map(p=>p.id)];
const work=order.map((id,index)=>{
  const project=projects.find(p=>p.id===id);
  return {project,asset:projectPreview(project,'home'),index};
});

function HomeNavigation(){
  const [open,setOpen]=useState(false);
  const menu=useRef(null);
  const goHome=event=>{
    setOpen(false);
    if(location.hash!=='#inicio')return;
    event.preventDefault();
    window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  };
  useEffect(()=>{
    if(open){menu.current?.showModal();document.body.style.overflow='hidden'}
    else{menu.current?.close();document.body.style.overflow=''}
    return()=>{document.body.style.overflow=''};
  },[open]);
  return <>
    <header className="parallax-header"><a href="#inicio" aria-label="Romina Pereyra, inicio" onClick={goHome}>R.P.</a><button type="button" aria-label="Abrir menú" aria-haspopup="dialog" aria-controls="home-menu" aria-expanded={open} onClick={()=>setOpen(true)}><img src={image('menu.svg')} alt="" width="26" height="26"/></button></header>
    <dialog ref={menu} className="parallax-menu" id="home-menu" aria-label="Navegación principal" onCancel={()=>setOpen(false)}><button className="parallax-menu-close" type="button" onClick={()=>setOpen(false)} aria-label="Cerrar menú"><img src={image('x.svg')} alt="" width="28" height="28"/></button><nav>{[['Inicio','#inicio'],['Proyectos','#proyectos'],['Sobre mí','#info'],['Contacto',mail]].map(([label,href])=><a href={href} target={href===mail?"_blank":undefined} rel={href===mail?"noreferrer":undefined} key={label} onClick={href==='#inicio'?goHome:()=>setOpen(false)}>{label}</a>)}</nav></dialog>
  </>;
}

function Artwork({entry}){
  const ref=useRef(null);
  const [visible,setVisible]=useState(false);
  useEffect(()=>{
    if(!('IntersectionObserver' in window)||matchMedia('(prefers-reduced-motion: reduce)').matches){setVisible(true);return}
    const observer=new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting)){setVisible(true);observer.disconnect()}},{rootMargin:'100% 0px 100% 0px'});
    observer.observe(ref.current);
    return()=>observer.disconnect();
  },[]);
  return <a ref={ref} className="parallax-work-item" data-visible={visible} href={'#proyecto/'+entry.project.id} aria-label={'Ver '+entry.project.title+' — '+entry.project.subtitle}><PreviewImage asset={entry.asset} alt={entry.project.title+' — '+entry.project.subtitle}/></a>;
}

export default function ParallaxHome({Name}){
  const section=useRef(null),layer=useRef(null),grid=useRef(null),center=useRef(null),photos=useRef([]),scrollCue=useRef(null);
  useEffect(()=>{
    const reduced=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
    let frame=0,visible=true,last=0,started=0,current={x:.5,y:.5,progress:0},target={x:.5,y:.5},positions=[];
    const layout=()=>{
      if(!grid.current||!center.current)return;
      const stage=section.current.querySelector('.parallax-stage').getBoundingClientRect(),c=center.current.getBoundingClientRect(),w=grid.current.clientWidth,h=grid.current.clientHeight;
      const mobile=w<768,gap=mobile?14:24,pad=mobile?24:36,rows=mobile?[[0,1,2],[3,4,5],[6,7,8],[9,10,11]]:[[0,1,2,3,4,5],[6,7,8,9,10,11]];
      const bandRows=mobile?2:1,topStart=mobile?70:76,topEnd=c.top-stage.top-28,bottomStart=c.bottom-stage.top+28,bottomEnd=h-76;
      positions=[];
      for(const band of [0,1]){
        const bandTop=band?bottomStart:topStart,bandBottom=band?bottomEnd:topEnd,available=Math.max(30,bandBottom-bandTop),groups=rows.slice(band*bandRows,(band+1)*bandRows);
        const maxHeight=Math.max(24,(available-(groups.length-1)*gap)/groups.length);
        const heights=groups.map(group=>Math.min(maxHeight,(w-pad*2-gap*(group.length-1))/group.reduce((sum,index)=>sum+heroPhotos[index].width/heroPhotos[index].height,0)));
        let y=bandTop+Math.max(0,(available-heights.reduce((sum,height)=>sum+height,0)-gap*(groups.length-1))/2);
        groups.forEach((group,row)=>{
          const height=heights[row],widths=group.map(index=>height*heroPhotos[index].width/heroPhotos[index].height),total=widths.reduce((sum,width)=>sum+width,0)+gap*(group.length-1);
          let x=(w-total)/2;
          group.forEach((index,column)=>{const position={x:x+widths[column]/2,y:y+height/2+(mobile?0:[-4,6,-6,4,-2,5][column%6]),w:widths[column],h:height,angle:mobile?0:[-1.4,1,-.9,1.5,-1.2,.8][column%6]};positions[index]=position;const photo=photos.current[index];if(photo){photo.style.left=position.x+'px';photo.style.top=position.y+'px';photo.style.width=position.w+'px';photo.style.height=position.h+'px';photo.style.setProperty('--photo-angle',position.angle+'deg')}x+=widths[column]+gap});
          y+=height+gap;
        });
      }
    };
    const mouse=event=>{if(fine.matches)target={x:event.clientX/innerWidth,y:event.clientY/innerHeight}};
    const reset=()=>{target={x:.5,y:.5}};
    const paint=time=>{
      frame=0;if(!visible||document.hidden||reduced.matches)return;
      if(!started)started=time;
      const step=Math.min((time-(last||time-16.7))/16.7,4);last=time;
      current.x+=(target.x-current.x)*(1-Math.pow(.97,step));current.y+=(target.y-current.y)*(1-Math.pow(.97,step));
      const progress=Math.max(0,Math.min(1,-section.current.getBoundingClientRect().top/Math.max(section.current.offsetHeight-innerHeight,1)));
      current.progress+=(progress-current.progress)*(1-Math.pow(.92,step));
      const intro=1-Math.pow(1-Math.min((time-started)/1100,1),3);
      grid.current.style.opacity=String(intro);
      layer.current.style.transform=`scale(${1+.025*current.progress})`;layer.current.style.opacity=String(1-current.progress);layer.current.style.filter=`blur(${30*current.progress}px)`;
      photos.current.forEach((photo,index)=>{if(photo){const depth=1+index%3,sign=index%2?1:-1;photo.style.transform=`translate3d(calc(-50% + ${sign*(.5-current.x)*depth*2}px),calc(-50% + ${sign*(.5-current.y)*depth*2}px),0) rotate(${positions[index]?.angle||0}deg)`}});
      if(scrollCue.current)scrollCue.current.style.opacity=String(Math.max(0,1-current.progress*3));
      frame=requestAnimationFrame(paint);
    };
    const start=()=>{if(!frame&&!reduced.matches&&visible&&!document.hidden){last=0;frame=requestAnimationFrame(paint)}};
    const preference=()=>{cancelAnimationFrame(frame);frame=0;if(reduced.matches){grid.current?.style.removeProperty('opacity');layer.current?.removeAttribute('style');photos.current.forEach(photo=>photo?.style.removeProperty('transform'));scrollCue.current?.removeAttribute('style')}else start()};
    const resize=new ResizeObserver(()=>{layout();start()});resize.observe(grid.current);resize.observe(center.current);
    layout();
    const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible)start();else{cancelAnimationFrame(frame);frame=0}},{rootMargin:'100px'});observer.observe(section.current);
    addEventListener('pointermove',mouse,{passive:true});addEventListener('blur',reset);document.addEventListener('visibilitychange',start);reduced.addEventListener('change',preference);start();
    return()=>{cancelAnimationFrame(frame);resize.disconnect();observer.disconnect();removeEventListener('pointermove',mouse);removeEventListener('blur',reset);document.removeEventListener('visibilitychange',start);reduced.removeEventListener('change',preference)};
  },[]);
  const scrollToWork=event=>{event.preventDefault();document.getElementById('home-work')?.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});document.getElementById('home-work')?.focus({preventScroll:true})};
  return <div className="parallax-home">
    <HomeNavigation/>
    <section className="parallax-hero" ref={section} aria-labelledby="home-title"><div className="parallax-stage">
      <div className="parallax-center" ref={center}><h1 className="parallax-title" id="home-title" aria-label="Romina Pereyra"><Name animated/></h1><a className="parallax-contact" href={mail} target="_blank" rel="noreferrer">HABLEMOS</a></div>
      <div className="parallax-images" ref={layer} aria-hidden="true"><div className="parallax-grid" ref={grid}>{heroPhotos.map((asset,index)=><div className="parallax-photo" key={heroIds[index]} ref={node=>{photos.current[index]=node}}><PreviewImage asset={asset} loading="eager" fetchPriority={index<6?'high':'auto'}/></div>)}</div></div>
      <a className="parallax-scroll" ref={scrollCue} href="#home-work" onClick={scrollToWork}><img src={image('arrow-down.svg')} alt="" width="18" height="26"/><span>DESLIZA</span></a>
    </div></section>
    <section className="parallax-work" id="home-work" tabIndex="-1" aria-label="Los 17 proyectos del portfolio">{[work.slice(0,6),work.slice(6,12),work.slice(12)].map((column,index)=><div className="parallax-work-column" key={index}>{column.map(entry=><Artwork key={entry.project.id} entry={entry}/>)}</div>)}</section>
  </div>;
}
