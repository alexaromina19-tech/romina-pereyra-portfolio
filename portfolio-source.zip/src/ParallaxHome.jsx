import {useEffect,useRef,useState} from 'react';
import projects from './projects.json';
import detailAssets from './detail-assets.json';
import {contactHref as mail} from './contact.js';
import {projectPreview} from './project-previews.js';
import PreviewImage from './PreviewImage.jsx';
import useScrollReveal from './useScrollReveal.js';
import './parallax-home.css';

const image=file=>import.meta.env.BASE_URL+file+'?v=20261024-native';
// An irregular constellation keeps the original photo proportions and soft depth.
const heroIds=['kubik','marshall','kota-yamaji','switch-seat','nightfall','chips-ahoy','time-out','aurea','silla-05','trofeo','mescladis','moonlit'];
const heroPhotos=heroIds.map(id=>projectPreview(projects.find(project=>project.id===id),'hero'));
const order=['kubik','nightfall','kota-yamaji',...projects.filter(p=>!['kubik','nightfall','kota-yamaji'].includes(p.id)).map(p=>p.id)];
const work=order.map((id,index)=>{
  const project=projects.find(p=>p.id===id);
  return {project,asset:projectPreview(project,'home'),index};
});

function HomeNavigation(){
  const [open,setOpen]=useState(false);
  const menu=useRef(null);
  const goHome=event=>{
    setOpen(false);
    if(location.hash!=='#inicio')return;
    event.preventDefault();
    window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  };
  useEffect(()=>{
    if(open){menu.current?.showModal();document.body.style.overflow='hidden'}
    else{menu.current?.close();document.body.style.overflow=''}
    return()=>{document.body.style.overflow=''};
  },[open]);
  return <>
    <header className="parallax-header"><a href="#inicio" aria-label="Romina Pereyra, inicio" onClick={goHome}>R.P.</a><button type="button" aria-label="Abrir menú" aria-haspopup="dialog" aria-controls="home-menu" aria-expanded={open} onClick={()=>setOpen(true)}><img src={image('menu.svg')} alt="" width="26" height="26"/></button></header>
    <dialog ref={menu} className="parallax-menu" id="home-menu" aria-label="Navegación principal" onCancel={()=>setOpen(false)}><button className="parallax-menu-close" type="button" onClick={()=>setOpen(false)} aria-label="Cerrar menú"><img src={image('x.svg')} alt="" width="28" height="28"/></button><nav>{[['Inicio','#inicio'],['Proyectos','#proyectos'],['Sobre mí','#info'],['Contacto',mail]].map(([label,href])=><a href={href} target={href===mail?"_blank":undefined} rel={href===mail?"noreferrer":undefined} key={label} onClick={href==='#inicio'?goHome:()=>setOpen(false)}>{label}</a>)}</nav></dialog>
  </>;
}

function Artwork({entry}){
  return <a className="parallax-work-item" data-scroll-reveal="" href={'#proyecto/'+entry.project.id} aria-label={'Ver '+entry.project.title+' — '+entry.project.subtitle}><span className="scroll-reveal-content"><PreviewImage asset={entry.asset} alt={entry.project.title+' — '+entry.project.subtitle}/></span></a>;
}

export default function ParallaxHome({Name}){
  const section=useRef(null),layer=useRef(null),grid=useRef(null),center=useRef(null),photos=useRef([]),scrollCue=useRef(null),workGallery=useRef(null);
  const [introReady,setIntroReady]=useState(false);
  const [introPhase,setIntroPhase]=useState('photos');
  const phase=useRef('photos'),phaseTimer=useRef(null),finishedPhotos=useRef(new Set());
  const showPhase=next=>{phase.current=next;setIntroPhase(next)};
  const advance=next=>{
    clearTimeout(phaseTimer.current);
    phaseTimer.current=setTimeout(()=>{phaseTimer.current=null;showPhase(next)},100);
  };
  const finishPhoto=(event,index)=>{
    if(event.target!==event.currentTarget||event.animationName!=='hero-photo-arrive'||phase.current!=='photos')return;
    finishedPhotos.current.add(index);
    if(finishedPhotos.current.size===heroPhotos.length)advance('name');
  };
  const finishText=(event,from,next,animation)=>{
    if(event.animationName===animation&&phase.current===from)advance(next);
  };
  useScrollReveal(workGallery);
  useEffect(()=>{
    let cancelled=false,started=0,nextPhoto=0;
    const loaded=new Set(),cleanups=[];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    const preference=()=>{
      if(!reduced.matches)return;
      clearTimeout(phaseTimer.current);phaseTimer.current=null;
      showPhase('complete');setIntroReady(true);
    };
    reduced.addEventListener('change',preference);preference();
    const arrive=index=>{
      if(cancelled||!started||!loaded.has(index)||phase.current!=='photos')return;
      const photo=photos.current[index]?.querySelector('.hero-photo-arrival');
      if(!photo||photo.dataset.photoReady==='true')return;
      const now=performance.now(),due=Math.max(now,started+index*70,nextPhoto);
      photo.style.setProperty('--hero-delay',Math.round(due-now)+'ms');
      photo.dataset.photoReady='true';nextPhoto=due+70;
    };
    photos.current.forEach((photo,index)=>{
      const img=photo?.querySelector('img');if(!img)return;
      const ready=async()=>{if(img.decode&&img.naturalWidth)try{await img.decode()}catch{}if(cancelled)return;loaded.add(index);arrive(index)};
      if(img.complete)ready();
      else{img.addEventListener('load',ready,{once:true});img.addEventListener('error',ready,{once:true});cleanups.push(()=>{img.removeEventListener('load',ready);img.removeEventListener('error',ready)})}
    });
    Promise.allSettled(document.fonts?[document.fonts.load('400 100px Pinyon'),document.fonts.load('400 24px Bodoni')]:[]).then(()=>{
      if(cancelled)return;started=performance.now();setIntroReady(true);heroPhotos.forEach((_,index)=>arrive(index));
    });
    return()=>{cancelled=true;clearTimeout(phaseTimer.current);reduced.removeEventListener('change',preference);cleanups.forEach(cleanup=>cleanup())};
  },[]);
  useEffect(()=>{
    const reduced=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
    let frame=0,visible=true,last=0,current={x:.5,y:.5,progress:0},target={x:.5,y:.5},positions=[];
    const layout=()=>{
      if(!grid.current||!center.current)return;
      const w=grid.current.clientWidth,h=grid.current.clientHeight,mobile=w<768,gap=mobile?18:28,pad=mobile?18:28;
      // Offset anchors distribute the collage across the screen, rather than in rows.
      const anchors=mobile?
        [[.20,.16],[.55,.12],[.81,.25],[.15,.35],[.48,.30],[.83,.375],[.17,.70],[.84,.67],[.13,.84],[.44,.77],[.50,.91],[.80,.89]]:
        [[.11,.23],[.36,.14],[.65,.23],[.90,.30],[.13,.52],[.50,.28],[.54,.81],[.89,.60],[.11,.83],[.33,.79],[.70,.72],[.86,.88]];
      const angles=[-4,3,-2.5,4,-3,2.5,-3.5,3,-2,4,-4,2];
      positions=anchors.map(([x,y],index)=>{
        const ratio=heroPhotos[index].width/heroPhotos[index].height,area=w*h*(mobile?.024:.026)*[1,.9,1.1,.95,1,.9,1.1,.95,1,1,.9,1][index];
        let width=Math.sqrt(area*ratio),height=width/ratio;
        const scale=Math.min(1,w*(mobile?.30:.22)/width,h*(mobile?.17:.30)/height);
        width*=scale;height*=scale;
        return {x:x*w,y:y*h,w:width,h:height,angle:angles[index]*(mobile?.6:1)};
      });
      const clamp=position=>{
        const tilt=Math.abs(position.angle)*Math.PI/180,halfW=(position.w*Math.cos(tilt)+position.h*Math.sin(tilt))/2,halfH=(position.h*Math.cos(tilt)+position.w*Math.sin(tilt))/2;
        position.x=Math.max(pad+halfW,Math.min(w-pad-halfW,position.x));
        position.y=Math.max(68+halfH,Math.min(h-56-halfH,position.y));
      };
      // Resolve close neighbours with one common gutter, preserving the loose anchors.
      for(let pass=0;pass<32;pass++){
        positions.forEach(clamp);
        for(let i=0;i<positions.length;i++)for(let j=i+1;j<positions.length;j++){
          const a=positions[i],b=positions[j],dx=b.x-a.x,dy=b.y-a.y;
          const overlapX=(a.w+b.w)/2+gap-Math.abs(dx),overlapY=(a.h+b.h)/2+gap-Math.abs(dy);
          if(overlapX>0&&overlapY>0){
            if(overlapX<overlapY){const shift=(overlapX+.1)/2*(dx>=0?1:-1);a.x-=shift;b.x+=shift}
            else{const shift=(overlapY+.1)/2*(dy>=0?1:-1);a.y-=shift;b.y+=shift}
          }
        }
      }
      positions.forEach((position,index)=>{
        clamp(position);const photo=photos.current[index];
        if(photo){photo.style.left=position.x+'px';photo.style.top=position.y+'px';photo.style.width=position.w+'px';photo.style.height=position.h+'px';photo.style.setProperty('--photo-angle',position.angle+'deg')}
      });
    };
    const mouse=event=>{if(fine.matches)target={x:event.clientX/innerWidth,y:event.clientY/innerHeight}};
    const reset=()=>{target={x:.5,y:.5}};
    const paint=time=>{
      frame=0;if(!visible||document.hidden||reduced.matches)return;
      const step=Math.min((time-(last||time-16.7))/16.7,4);last=time;
      current.x+=(target.x-current.x)*(1-Math.pow(.97,step));current.y+=(target.y-current.y)*(1-Math.pow(.97,step));
      const progress=Math.max(0,Math.min(1,-section.current.getBoundingClientRect().top/Math.max(section.current.offsetHeight-innerHeight,1)));
      current.progress+=(progress-current.progress)*(1-Math.pow(.92,step));
      grid.current.style.opacity='1';
      layer.current.style.transform=`scale(${1+.025*current.progress})`;layer.current.style.opacity=String(1-current.progress);layer.current.style.filter=`blur(${1.4+28.6*current.progress}px)`;
      photos.current.forEach((photo,index)=>{if(photo){const depth=1+index%3,sign=index%2?1:-1;photo.style.transform=`translate3d(calc(-50% + ${sign*(.5-current.x)*depth*2}px),calc(-50% + ${sign*(.5-current.y)*depth*2}px),0) rotate(${positions[index]?.angle||0}deg)`}});
      if(scrollCue.current)scrollCue.current.style.opacity=String(Math.max(0,1-current.progress*3));
      frame=requestAnimationFrame(paint);
    };
    const start=()=>{if(!frame&&!reduced.matches&&visible&&!document.hidden){last=0;frame=requestAnimationFrame(paint)}};
    const preference=()=>{cancelAnimationFrame(frame);frame=0;if(reduced.matches){grid.current?.style.removeProperty('opacity');layer.current?.removeAttribute('style');photos.current.forEach(photo=>photo?.style.removeProperty('transform'));scrollCue.current?.removeAttribute('style')}else start()};
    const resize=new ResizeObserver(()=>{layout();start()});resize.observe(grid.current);resize.observe(center.current);
    layout();
    const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible)start();else{cancelAnimationFrame(frame);frame=0}},{rootMargin:'100px'});observer.observe(section.current);
    addEventListener('pointermove',mouse,{passive:true});addEventListener('blur',reset);document.addEventListener('visibilitychange',start);reduced.addEventListener('change',preference);start();
    return()=>{cancelAnimationFrame(frame);resize.disconnect();observer.disconnect();removeEventListener('pointermove',mouse);removeEventListener('blur',reset);document.removeEventListener('visibilitychange',start);reduced.removeEventListener('change',preference)};
  },[]);
  const scrollToWork=event=>{event.preventDefault();document.getElementById('home-work')?.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});document.getElementById('home-work')?.focus({preventScroll:true})};
  return <div className="parallax-home">
    <HomeNavigation/>
    <section className="parallax-hero" ref={section} data-intro-ready={introReady} data-intro-phase={introPhase} aria-labelledby="home-title"><div className="parallax-stage">
      <div className="parallax-center" ref={center}><h1 className="parallax-title" id="home-title" aria-label="Romina Pereyra" onAnimationEnd={event=>finishText(event,'name','product','calligraphy-arrive')}><Name calligraphy entrance/></h1><p className="parallax-role"><span className="parallax-role-product" onAnimationEnd={event=>finishText(event,'product','graphic','role-field-arrive')}>Diseñadora de producto</span>{' '}<span aria-hidden="true" className="parallax-role-dot">·</span>{' '}<span className="parallax-role-graphic" onAnimationEnd={event=>finishText(event,'graphic','complete','role-field-arrive')}>Diseño gráfico y editorial</span></p><a className="parallax-contact" href={mail} target="_blank" rel="noreferrer">HABLEMOS</a></div>
      <div className="parallax-images" ref={layer} aria-hidden="true"><div className="parallax-grid" ref={grid}>{heroPhotos.map((asset,index)=><div className="parallax-photo" key={heroIds[index]} ref={node=>{photos.current[index]=node}}><div className="hero-photo-arrival" onAnimationEnd={event=>finishPhoto(event,index)} style={{'--hero-delay':index*70+'ms','--hero-enter-x':['-180px','160px','-65px','90px'][index%4],'--hero-enter-y':['65px','-70px','-180px','170px'][index%4],'--hero-enter-angle':index%2?'7deg':'-7deg'}}><PreviewImage asset={asset} loading="eager" fetchPriority={index<6?'high':'auto'}/></div></div>)}</div></div>
      <a className="parallax-scroll" ref={scrollCue} href="#home-work" onClick={scrollToWork}><img src={image('arrow-down.svg')} alt="" width="18" height="26"/><span>DESLIZA</span></a>
    </div></section>
    <section ref={workGallery} className="parallax-work" id="home-work" tabIndex="-1" aria-label="Los 17 proyectos del portfolio">{[work.slice(0,6),work.slice(6,12),work.slice(12)].map((column,index)=><div className="parallax-work-column" key={index}>{column.map(entry=><Artwork key={entry.project.id} entry={entry}/>)}</div>)}</section>
  </div>;
}
