import {useEffect,useRef,useState} from 'react';
import projects from './projects.json';
import {contactHref as mail} from './contact.js';
import {projectPreview} from './project-previews.js';
import PreviewImage from './PreviewImage.jsx';
import useScrollReveal from './useScrollReveal.js';
import './parallax-home.css';

const image=file=>import.meta.env.BASE_URL+file+'?v=20261024-native';
const order=['kubik','nightfall','kota-yamaji',...projects.filter(p=>!['kubik','nightfall','kota-yamaji'].includes(p.id)).map(p=>p.id)];
const work=order.map((id,index)=>{
  const project=projects.find(p=>p.id===id);
  return {project,asset:projectPreview(project,'home'),index};
});

function HomeNavigation(){
  const [open,setOpen]=useState(false);
  const menu=useRef(null);
  const goHome=event=>{
    setOpen(false);
    if(location.hash!=='#inicio')return;
    event.preventDefault();
    window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  };
  useEffect(()=>{
    if(open){menu.current?.showModal();document.body.style.overflow='hidden'}
    else{menu.current?.close();document.body.style.overflow=''}
    return()=>{document.body.style.overflow=''};
  },[open]);
  return <>
    <header className="parallax-header"><a href="#inicio" aria-label="Romina Pereyra, inicio" onClick={goHome}>R.P.</a><button type="button" aria-label="Abrir menú" aria-haspopup="dialog" aria-controls="home-menu" aria-expanded={open} onClick={()=>setOpen(true)}><img src={image('menu.svg')} alt="" width="26" height="26"/></button></header>
    <dialog ref={menu} className="parallax-menu" id="home-menu" aria-label="Navegación principal" onCancel={()=>setOpen(false)}><button className="parallax-menu-close" type="button" onClick={()=>setOpen(false)} aria-label="Cerrar menú"><img src={image('x.svg')} alt="" width="28" height="28"/></button><nav>{[['Inicio','#inicio'],['Proyectos','#proyectos'],['Sobre mí','#info'],['Contacto',mail]].map(([label,href])=><a href={href} target={href===mail?"_blank":undefined} rel={href===mail?"noreferrer":undefined} key={label} onClick={href==='#inicio'?goHome:()=>setOpen(false)}>{label}</a>)}</nav></dialog>
  </>;
}

function Artwork({entry}){
  return <a className="parallax-work-item" data-scroll-reveal="" href={'#proyecto/'+entry.project.id} aria-label={'Ver '+entry.project.title+' — '+entry.project.subtitle}><span className="scroll-reveal-content"><PreviewImage asset={entry.asset} alt={entry.project.title+' — '+entry.project.subtitle}/></span></a>;
}

export default function ParallaxHome({Name}){
  const section=useRef(null),stage=useRef(null),video=useRef(null),workGallery=useRef(null);
  const [introReady,setIntroReady]=useState(false),[introPhase,setIntroPhase]=useState('video');
  const [mediaReady,setMediaReady]=useState(false),[fontsReady,setFontsReady]=useState(false);
  const [playWanted,setPlayWanted]=useState(()=>typeof matchMedia==='function'?!matchMedia('(prefers-reduced-motion: reduce)').matches:true);
  const [playing,setPlaying]=useState(false),[hasFrame,setHasFrame]=useState(false),[hasPlayed,setHasPlayed]=useState(false);
  const phase=useRef('video'),phaseTimer=useRef(null),syncPlayback=useRef(()=>{});
  const showPhase=next=>{phase.current=next;setIntroPhase(next)};
  const advance=next=>{
    clearTimeout(phaseTimer.current);
    phaseTimer.current=setTimeout(()=>{phaseTimer.current=null;showPhase(next)},100);
  };
  const finishText=(event,from,next,animation)=>{
    if(event.animationName===animation&&phase.current===from)advance(next);
  };
  useScrollReveal(workGallery);
  useEffect(()=>{
    let cancelled=false;
    const fallback=setTimeout(()=>{if(!cancelled)setMediaReady(true)},1600);
    Promise.allSettled(document.fonts?[document.fonts.load('400 100px Pinyon'),document.fonts.load('400 24px Bodoni')]:[]).then(()=>{if(!cancelled)setFontsReady(true)});
    return()=>{cancelled=true;clearTimeout(fallback)};
  },[]);
  useEffect(()=>{
    if(!mediaReady||!fontsReady)return;
    setIntroReady(true);
    if(phase.current==='video')showPhase('name');
  },[mediaReady,fontsReady]);
  useEffect(()=>{
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    const preference=()=>{
      setPlayWanted(!reduced.matches);
      if(!reduced.matches)return;
      clearTimeout(phaseTimer.current);phaseTimer.current=null;
      showPhase('complete');setIntroReady(true);
    };
    reduced.addEventListener('change',preference);preference();
    return()=>{clearTimeout(phaseTimer.current);reduced.removeEventListener('change',preference)};
  },[]);
  useEffect(()=>{
    const player=video.current;
    if(!player)return;
    let inView=true,cancelled=false;
    const sync=()=>{
      if(cancelled)return;
      if(playWanted&&inView&&!document.hidden){
        if(player.readyState>=2)player.play().catch(()=>{if(!cancelled)setPlaying(false)});
      }else player.pause();
    };
    syncPlayback.current=sync;
    const observer='IntersectionObserver' in window?new IntersectionObserver(entries=>{inView=entries[0].isIntersecting;sync()},{threshold:0}):null;
    if(stage.current)observer?.observe(stage.current);
    document.addEventListener('visibilitychange',sync);
    sync();
    return()=>{cancelled=true;observer?.disconnect();document.removeEventListener('visibilitychange',sync);syncPlayback.current=()=>{};player.pause()};
  },[playWanted]);
  const togglePlayback=()=>{
    const next=!playing;
    setPlayWanted(next);
    if(next)video.current?.play().catch(()=>setPlaying(false));else video.current?.pause();
  };
  const videoReady=()=>{setHasFrame(true);setMediaReady(true);syncPlayback.current()};
  const scrollToWork=event=>{event.preventDefault();document.getElementById('home-work')?.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});document.getElementById('home-work')?.focus({preventScroll:true})};
  return <div className="parallax-home">
    <HomeNavigation/>
    <section className="parallax-hero" ref={section} data-intro-ready={introReady} data-intro-phase={introPhase} aria-labelledby="home-title"><div ref={stage} className="parallax-stage">
      <div className="hero-video" aria-hidden="true">
        <img className="hero-video-poster" src={import.meta.env.BASE_URL+'romina-welding-poster.webp?v=20261026'} alt="" width="1280" height="720" onLoad={()=>setMediaReady(true)} onError={()=>setMediaReady(true)} fetchPriority="high"/>
        <video ref={video} className="hero-video-player" data-frame-ready={hasFrame&&(playing||hasPlayed)} src={import.meta.env.BASE_URL+'romina-welding-loop.mp4?v=20261026'} poster={import.meta.env.BASE_URL+'romina-welding-poster.webp?v=20261026'} width="1280" height="720" autoPlay={playWanted} muted loop playsInline preload="auto" onLoadedData={videoReady} onPlaying={()=>{setPlaying(true);setHasPlayed(true)}} onPause={()=>setPlaying(false)} onError={()=>{setMediaReady(true);setPlaying(false)}}/>
      </div>
      <div className="parallax-center"><h1 className="parallax-title" id="home-title" aria-label="Romina Pereyra" onAnimationEnd={event=>finishText(event,'name','product','calligraphy-arrive')}><Name calligraphy entrance/></h1><p className="parallax-role"><span className="parallax-role-product" onAnimationEnd={event=>finishText(event,'product','graphic','role-field-arrive')}>Diseñadora de producto</span>{' '}<span aria-hidden="true" className="parallax-role-dot">·</span>{' '}<span className="parallax-role-graphic" onAnimationEnd={event=>finishText(event,'graphic','complete','role-field-arrive')}>Diseño gráfico y editorial</span></p><a className="parallax-contact" href={mail} target="_blank" rel="noreferrer">HABLEMOS</a></div>
      <button className="hero-video-toggle" type="button" onClick={togglePlayback} aria-label={playing?'Pausar vídeo del taller':'Reproducir vídeo del taller'} aria-pressed={playing}><span aria-hidden="true">{playing?'Ⅱ':'▶'}</span>{playing?'Pausar':'Reproducir'}</button>
      <a className="parallax-scroll" href="#home-work" onClick={scrollToWork}><img src={image('arrow-down.svg')} alt="" width="18" height="26"/><span>DESLIZA</span></a>
    </div></section>
    <section ref={workGallery} className="parallax-work" id="home-work" tabIndex="-1" aria-label="Los 17 proyectos del portfolio">{[work.slice(0,6),work.slice(6,12),work.slice(12)].map((column,index)=><div className="parallax-work-column" key={index}>{column.map(entry=><Artwork key={entry.project.id} entry={entry}/>)}</div>)}</section>
  </div>;
}
