import {useEffect,useRef,useState} from 'react';
import projects from './projects.json';
import detailAssets from './detail-assets.json';
import {contactHref as mail} from './contact.js';
import './parallax-home.css';

const image=file=>import.meta.env.BASE_URL+file+'?v=20261024-native';
// The twelve positions, proportions and depth values follow the selected template.
const composition=[
  ['kubik',0,633,944,-5.4,-7.6,1,-1],
  ['marshall',2,705,489,7.1,-6.8,0,1],
  ['kota-yamaji',5,523,781,-7,2,2,-1],
  ['switch-seat',3,523,784,4.2,-2.1,0,1],
  ['nightfall',4,523,784,-8.7,-2.1,4,1],
  ['chips-ahoy',1,507,761,9.2,-4.3,2,1],
  ['switch-seat',1,1323,743,-11.1,10.4,2,1],
  ['aurea',1,375,563,-3.7,13.2,5,1],
  ['time-out',5,523,784,-9,-10.6,0,1],
  ['trofeo',1,422,632,7.1,1.8,2,-1],
  ['mescladis',0,523,370,-8.2,.7,3,1],
  ['moonlit',1,423,620,5.4,3.3,0,1],
];
const order=['kubik','nightfall','kota-yamaji',...projects.filter(p=>!['kubik','nightfall','kota-yamaji'].includes(p.id)).map(p=>p.id)];
const work=order.map((id,index)=>{
  const project=projects.find(p=>p.id===id),views=detailAssets[id].results;
  // Mix complete portrait, square and landscape photographs, as in the source gallery.
  const selection={kubik:0,nightfall:4,'kota-yamaji':5,marshall:2,'chips-ahoy':1,grease:1,'switch-seat':3,'time-out':5,trizart:1,mescladis:0,'anillos-caramelo':0,aurea:1,trofeo:1,'silla-05':0,'red-trackwear':1,moonlit:1,'amics-rambla':4};
  return {project,asset:views[selection[id]]||views[0],index};
});

function HomeNavigation(){
  const [open,setOpen]=useState(false);
  const menu=useRef(null);
  const goHome=event=>{
    setOpen(false);
    if(location.hash!=='#inicio')return;
    event.preventDefault();
    window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  };
  useEffect(()=>{
    if(open){menu.current?.showModal();document.body.style.overflow='hidden'}
    else{menu.current?.close();document.body.style.overflow=''}
    return()=>{document.body.style.overflow=''};
  },[open]);
  return <>
    <header className="parallax-header"><a href="#inicio" aria-label="Romina Pereyra, inicio" onClick={goHome}>R.P.</a><button type="button" aria-label="Abrir menú" aria-haspopup="dialog" aria-controls="home-menu" aria-expanded={open} onClick={()=>setOpen(true)}><img src={image('menu.svg')} alt="" width="26" height="26"/></button></header>
    <dialog ref={menu} className="parallax-menu" id="home-menu" aria-label="Navegación principal" onCancel={()=>setOpen(false)}><button className="parallax-menu-close" type="button" onClick={()=>setOpen(false)} aria-label="Cerrar menú"><img src={image('x.svg')} alt="" width="28" height="28"/></button><nav>{[['Inicio','#inicio'],['Proyectos','#proyectos'],['Sobre mí','#info'],['Contacto',mail]].map(([label,href])=><a href={href} target={href===mail?"_blank":undefined} rel={href===mail?"noreferrer":undefined} key={label} onClick={href==='#inicio'?goHome:()=>setOpen(false)}>{label}</a>)}</nav></dialog>
  </>;
}

function Artwork({entry}){
  const ref=useRef(null);
  const [visible,setVisible]=useState(false);
  useEffect(()=>{
    if(!('IntersectionObserver' in window)||matchMedia('(prefers-reduced-motion: reduce)').matches){setVisible(true);return}
    const observer=new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting)){setVisible(true);observer.disconnect()}},{rootMargin:'100% 0px 100% 0px'});
    observer.observe(ref.current);
    return()=>observer.disconnect();
  },[]);
  return <a ref={ref} className="parallax-work-item" data-visible={visible} href={'#proyecto/'+entry.project.id} aria-label={'Ver '+entry.project.title+' — '+entry.project.subtitle}><img src={image(entry.asset.file)} alt={entry.project.title+' — '+entry.project.subtitle} width={entry.asset.width} height={entry.asset.height} loading="lazy"/></a>;
}

export default function ParallaxHome({Name}){
  const section=useRef(null),layer=useRef(null),grid=useRef(null),photos=useRef([]),scrollCue=useRef(null);
  useEffect(()=>{
    const reduced=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
    let frame=0,visible=true,last=0,started=0,current={x:.5,y:.5,progress:0},target={x:.5,y:.5};
    const mouse=event=>{if(fine.matches)target={x:event.clientX/innerWidth,y:event.clientY/innerHeight}};
    const reset=()=>{target={x:.5,y:.5}};
    const paint=time=>{
      frame=0;
      if(!visible||document.hidden||reduced.matches)return;
      if(!started)started=time;
      const step=Math.min((time-(last||time-16.7))/16.7,4);last=time;
      const easing=1-Math.pow(.97,step),scrollEasing=1-Math.pow(.92,step);
      current.x+=(target.x-current.x)*easing;current.y+=(target.y-current.y)*easing;
      const distance=Math.max(section.current.offsetHeight-innerHeight,1);
      const progress=Math.max(0,Math.min(1,-section.current.getBoundingClientRect().top/distance));
      current.progress+=(progress-current.progress)*scrollEasing;
      const intro=1-Math.pow(1-Math.min((time-started)/1400,1),3);
      if(grid.current){grid.current.style.transform=`translate3d(${20-current.x*40}vw,${20-current.y*40}vw,0) scale(${.8+.2*intro})`;grid.current.style.opacity=String(intro)}
      if(layer.current){layer.current.style.transform=`translate3d(0,${-250*current.progress}%,0) scale(${1+.3*current.progress})`;layer.current.style.opacity=String(1-current.progress);layer.current.style.filter=`blur(${30*current.progress}px)`}
      photos.current.forEach((photo,index)=>{const depth=composition[index][6],direction=composition[index][7];if(photo&&depth)photo.style.transform=`translate3d(${direction*(depth-current.x*depth*2)}vw,${direction*(depth-current.y*depth*2)}vw,0)`});
      if(scrollCue.current)scrollCue.current.style.opacity=String(Math.max(0,1-current.progress*3));
      frame=requestAnimationFrame(paint);
    };
    const start=()=>{if(!frame&&!reduced.matches&&visible&&!document.hidden){last=0;frame=requestAnimationFrame(paint)}};
    const preference=()=>{
      cancelAnimationFrame(frame);frame=0;
      if(reduced.matches){grid.current?.removeAttribute('style');layer.current?.removeAttribute('style');photos.current.forEach(photo=>photo?.removeAttribute('style'));scrollCue.current?.removeAttribute('style')}
      else start();
    };
    const observer='IntersectionObserver' in window?new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible)start();else{cancelAnimationFrame(frame);frame=0}},{rootMargin:'100px'}):null;
    observer?.observe(section.current);
    addEventListener('pointermove',mouse,{passive:true});addEventListener('blur',reset);document.addEventListener('visibilitychange',start);reduced.addEventListener('change',preference);
    start();
    return()=>{cancelAnimationFrame(frame);observer?.disconnect();removeEventListener('pointermove',mouse);removeEventListener('blur',reset);document.removeEventListener('visibilitychange',start);reduced.removeEventListener('change',preference)};
  },[]);
  const scrollToWork=event=>{event.preventDefault();document.getElementById('home-work')?.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});document.getElementById('home-work')?.focus({preventScroll:true})};
  return <div className="parallax-home">
    <HomeNavigation/>
    <section className="parallax-hero" ref={section} aria-labelledby="home-title"><div className="parallax-stage">
      <div className="parallax-center"><h1 className="parallax-title" id="home-title" aria-label="Romina Pereyra"><Name animated/></h1><a className="parallax-contact" href={mail} target="_blank" rel="noreferrer">HABLEMOS</a></div>
      <div className="parallax-images" ref={layer} aria-hidden="true"><div className="parallax-grid" ref={grid}>{composition.map(([id,view,w,h,top,left],index)=>{const asset=detailAssets[id].results[view]||detailAssets[id].results[0];return <div className={'parallax-photo'+(index===6?' parallax-photo-featured':'')} key={id+'-'+index} ref={node=>{photos.current[index]=node}}><img src={image(index===6?'switch-seat-home-clean.webp':asset.file)} alt="" width={w} height={h} style={{aspectRatio:w+'/'+h,top:top+'vw',left:left+'vw'}} loading="eager" fetchPriority={index<4?'high':'auto'}/></div>})}</div></div>
      <a className="parallax-scroll" ref={scrollCue} href="#home-work" onClick={scrollToWork}><img src={image('arrow-down.svg')} alt="" width="18" height="26"/><span>DESLIZA</span></a>
    </div></section>
    <section className="parallax-work" id="home-work" tabIndex="-1" aria-label="Los 17 proyectos del portfolio">{[work.slice(0,6),work.slice(6,12),work.slice(12)].map((column,index)=><div className="parallax-work-column" key={index}>{column.map(entry=><Artwork key={entry.project.id} entry={entry}/>)}</div>)}</section>
  </div>;
}
