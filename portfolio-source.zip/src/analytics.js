// Basic consent mode: this module does not even load Google until the visitor
// has accepted analytics. The caller also keeps an independent owner opt-out.
const AD_CONSENT={ad_storage:'denied',ad_user_data:'denied',ad_personalization:'denied'};
const EVENT_FIELDS={
  contact_click:new Set(['source','link_destination']),
  portfolio_open:new Set(['source','link_destination']),
  image_open:new Set(['project_id','gallery_kind','image_index','source']),
  project_filter:new Set(['source'])
};

function normaliseRoute(route){
  const value=String(route||'inicio').replace(/^#/,'');
  if(['inicio','info','proyectos'].includes(value))return value;
  if(/^proyecto\/[a-z0-9-]{1,64}$/.test(value))return value;
  if(/^proyectos\/(Producto|Gr%C3%A1fico|Gráfico|Editorial)$/.test(value))return 'proyectos';
  return 'inicio';
}

function scalar(value,max=100){
  if(typeof value==='number')return Number.isFinite(value)?value:undefined;
  if(typeof value!=='string')return undefined;
  return value.replace(/[\u0000-\u001f\u007f]/g,'').slice(0,max);
}

export function clearAnalyticsCookies({window:win=globalThis.window,document:doc=globalThis.document,basePath='/romina-pereyra-portfolio/',measurementId}={}){
  if(!doc||!win?.location)return;
  const measurementCookie=measurementId?'_ga_'+measurementId.replace(/^G-/,''):null;
  const names=String(doc.cookie||'').split(';').map(part=>part.trim().split('=')[0]).filter(name=>name==='_ga'||(measurementCookie?name===measurementCookie:/^_ga_[A-Za-z0-9]+$/.test(name)));
  const hostname=win.location.hostname;
  // Include host-only cookies plus the exact host and its leading-dot form.
  // Never touch unrelated cookies or parent domains such as github.io.
  for(const name of names)for(const path of new Set(['/',basePath,basePath.replace(/\/$/,'')]))for(const domain of ['',hostname,'.'+hostname]){
    doc.cookie=`${name}=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=${path}${domain?'; Domain='+domain:''}; SameSite=Lax`;
  }
}

export function createAnalytics({measurementId,productionHost='alexaromina19-tech.github.io',basePath='/romina-pereyra-portfolio/',debugMode=false,window:win=globalThis.window,document:doc=globalThis.document}={}){
  const validId=/^G-[A-Z0-9]{4,20}$/.test(measurementId||'');
  const path='/'+String(basePath).replace(/^\/+|\/+$/g,'')+'/';
  const eligible=Boolean(validId&&win&&doc&&win.location?.protocol==='https:'&&win.location.hostname===productionHost&&win.location.pathname.startsWith(path));
  const disableKey='ga-disable-'+measurementId;
  const origin='https://'+productionHost;
  let allowed=false,destroyed=false,script=null,loaded=false,configured=false,error=false;
  let current=null,lastSent=null,previousLocation=null,ownsQueue=false;

  const status=()=>({allowed,eligible,enabled:allowed&&eligible&&!destroyed&&!error,loaded,loading:Boolean(script&&!loaded&&!error),error,measurementId:validId?measurementId:null,currentPath:current?.location||null});
  const active=()=>allowed&&eligible&&!destroyed&&!error;
  const command=(...args)=>{if(active())win.gtag(...args)};
  const initialReferrer=()=>{
    try{
      const url=new URL(doc.referrer);
      if(!['http:','https:'].includes(url.protocol))return '';
      return url.origin===origin?origin+path+normaliseRoute(url.hash):url.origin+url.pathname;
    }catch{return ''}
  };
  const sendCurrent=()=>{
    if(!active()||!configured||!current||current.location===lastSent)return;
    const parameters={page_title:current.title,page_location:current.location,page_referrer:previousLocation||initialReferrer()};
    if(current.projectId)parameters.project_id=current.projectId;
    // Engagement events emitted by Google's own library must use the same
    // query-free virtual screen context as our explicit page_view events.
    command('set',{page_title:parameters.page_title,page_location:parameters.page_location,page_referrer:parameters.page_referrer});
    command('event','page_view',parameters);
    lastSent=current.location;
    previousLocation=current.location;
  };
  const clearQueue=()=>{
    if(ownsQueue&&Array.isArray(win?.dataLayer))win.dataLayer.length=0;
  };
  const load=()=>{
    if(!active()||configured)return;
    win[disableKey]=false;
    if(!win.dataLayer)win.dataLayer=[];
    if(typeof win.gtag!=='function'){
      ownsQueue=true;
      win.gtag=function(){win.dataLayer.push(arguments)};
    }
    command('consent','default',{analytics_storage:'denied',...AD_CONSENT});
    command('consent','update',{analytics_storage:'granted',...AD_CONSENT});
    command('set','ads_data_redaction',true);
    if(current)command('set',{page_title:current.title,page_location:current.location,page_referrer:previousLocation||initialReferrer()});
    command('js',new Date());
    command('config',measurementId,{
      send_page_view:false,
      allow_google_signals:false,
      allow_ad_personalization_signals:false,
      cookie_domain:productionHost,
      cookie_path:path,
      cookie_expires:60*60*24*180,
      cookie_update:false,
      ...(debugMode===true?{debug_mode:true}:{})
    });
    configured=true;
    if(!loaded){
      script=doc.createElement('script');
      script.async=true;
      script.src='https://www.googletagmanager.com/gtag/js?id='+measurementId;
      script.dataset.portfolioAnalytics='';
      const thisScript=script;
      script.onload=()=>{if(script===thisScript&&active())loaded=true};
      script.onerror=()=>{
        if(script!==thisScript)return;
        error=true;
        configured=false;
        win[disableKey]=true;
        script.remove();
        script=null;
        clearQueue();
        lastSent=null;
      };
      doc.head.appendChild(script);
    }
    sendCurrent();
  };

  function setAllowed(value){
    const next=Boolean(value)&&eligible&&!destroyed;
    if(!next){
      allowed=false;
      if(win&&validId)win[disableKey]=true;
      if(script){script.onload=null;script.onerror=null;script.remove();script=null}
      clearQueue();
      configured=false;
      lastSent=null;
      previousLocation=null;
      if(eligible)clearAnalyticsCookies({window:win,document:doc,basePath:path,measurementId});
      return status();
    }
    allowed=true;
    error=false;
    load();
    return status();
  }

  function page({route='inicio',title='Romina Pereyra — Portfolio',projectId}={}){
    const safeRoute=normaliseRoute(route);
    // GA reports strip fragments from the Page path dimension. Use virtual
    // analytics paths so each hash-routed screen remains a separate report row;
    // this does not navigate the browser or change any public project links.
    current={location:origin+path+safeRoute,title:scalar(title,160)};
    if(safeRoute.startsWith('proyecto/')&&projectId===safeRoute.slice(9))current.projectId=projectId;
    sendCurrent();
    return status();
  }

  function event(name,parameters={}){
    const fields=EVENT_FIELDS[name];
    if(!active()||!configured||!fields)return false;
    const clean={};
    for(const key of fields){const value=scalar(parameters[key]);if(value!==undefined)clean[key]=value}
    if(current){clean.page_location=current.location;clean.page_title=current.title}
    command('event',name,clean);
    return true;
  }

  function destroy(){setAllowed(false);destroyed=true;current=null}
  return {setAllowed,page,event,destroy,status};
}
