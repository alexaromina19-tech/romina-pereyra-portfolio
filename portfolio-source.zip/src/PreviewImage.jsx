const image=file=>import.meta.env.BASE_URL+file+'?v=20261024-focus';
export default function PreviewImage({asset,alt='',loading='lazy',fetchPriority}){
  const crop=asset.crop,style=crop?{'--preview-left':crop.left+'%','--preview-top':crop.top+'%','--preview-width':crop.width+'%','--preview-height':crop.height+'%'}:{};
  return <span className={'preview-frame'+(crop?' preview-frame-focused':'')} style={{aspectRatio:asset.width+'/'+asset.height,...style}}><img src={image(asset.file)} alt={alt} width={asset.width} height={asset.height} loading={loading} fetchPriority={fetchPriority}/></span>;
}
