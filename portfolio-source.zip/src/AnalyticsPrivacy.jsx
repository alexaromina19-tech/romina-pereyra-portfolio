import {useEffect,useRef,useState} from 'react';
import './analytics-privacy.css';
import {contactHref} from './contact.js';

export const CONSENT_KEY='romina.analytics.consent.v1';
export const EXCLUSION_KEY='romina.analytics.excluded.v1';
const MAX_AGE=180*24*60*60*1000;

function browserStorage(){
  try{return typeof window!=='undefined'?window.localStorage:null}catch{return null}
}

export function readAnalyticsPreferences(storage=browserStorage()){
  let consent='unknown',excluded=false;
  try{
    const saved=JSON.parse(storage?.getItem(CONSENT_KEY)||'null');
    const age=Date.now()-saved?.timestamp;
    if(saved&&['granted','denied'].includes(saved.choice)&&Number.isFinite(saved.timestamp)&&age>=0&&age<MAX_AGE)consent=saved.choice;
  }catch{}
  try{excluded=storage?.getItem(EXCLUSION_KEY)==='true'}catch{}
  return {consent,excluded};
}

function savePreference(key,value){
  try{browserStorage()?.setItem(key,value)}catch{}
}

export default function AnalyticsPrivacy({onPreferenceChange}){
  const [preferences,setPreferences]=useState(readAnalyticsPreferences);
  const [opened,setOpened]=useState(false);
  const dialog=useRef(null),opener=useRef(null),footerButton=useRef(null),callback=useRef(onPreferenceChange);
  callback.current=onPreferenceChange;

  useEffect(()=>{
    const initial=readAnalyticsPreferences();
    setPreferences(initial);
    callback.current?.(initial);
    const sync=event=>{
      if(event.key!==null&&event.key!==CONSENT_KEY&&event.key!==EXCLUSION_KEY)return;
      const next=readAnalyticsPreferences();
      callback.current?.(next);
      setPreferences(next);
    };
    window.addEventListener('storage',sync);
    return()=>window.removeEventListener('storage',sync);
  },[]);

  useEffect(()=>{
    if(opened&&!dialog.current?.open)dialog.current?.showModal();
    else if(!opened&&dialog.current?.open)dialog.current?.close();
  },[opened]);

  const open=event=>{
    opener.current=event.currentTarget;
    setOpened(true);
  };
  const close=()=>{
    dialog.current?.close();
    setOpened(false);
    (opener.current?.isConnected?opener.current:footerButton.current)?.focus?.({preventScroll:true});
  };
  const update=next=>{
    callback.current?.(next);
    setPreferences(next);
  };
  const choose=choice=>{
    savePreference(CONSENT_KEY,JSON.stringify({choice,timestamp:Date.now()}));
    update({...preferences,consent:choice});
    if(opened)close();
  };
  const exclude=event=>{
    const excluded=event.target.checked;
    savePreference(EXCLUSION_KEY,String(excluded));
    update({...preferences,excluded});
  };

  return <>
    <button className="privacy-footer-button" ref={footerButton} type="button" onClick={open}>Privacidad y cookies</button>
    {preferences.consent==='unknown'&&!preferences.excluded&&!opened&&<section className="analytics-banner" aria-label="Preferencias de analítica">
      <div className="analytics-banner-copy">
        <h2>Estadísticas del portfolio</h2>
        <p>Con tu permiso, Google Analytics mide las visitas, los proyectos consultados, el tiempo de interacción y los clics en contacto y Drive. Solo se activa si aceptas.</p>
        <button className="privacy-info-link" type="button" onClick={open}>Más información y preferencias</button>
      </div>
      <div className="privacy-actions">
        <button type="button" onClick={()=>choose('denied')}>Rechazar analítica</button>
        <button type="button" onClick={()=>choose('granted')}>Aceptar analítica</button>
      </div>
    </section>}
    <dialog className="privacy-dialog" ref={dialog} aria-labelledby="analytics-privacy-title" onCancel={event=>{event.preventDefault();close()}} onClick={event=>{if(event.target===dialog.current)close()}}>
      <header className="privacy-dialog-header"><h2 id="analytics-privacy-title">Privacidad y cookies</h2><button type="button" className="privacy-close" onClick={close} aria-label="Cerrar preferencias de privacidad">Cerrar ×</button></header>
      <div className="privacy-dialog-body">
        <p>Responsable: Romina Pereyra Bonija. Puedes contactar en <a href={contactHref} target="_blank" rel="noreferrer">alexaromina30@gmail.com</a>.</p>
        <h3>Estadísticas, con tu permiso</h3>
        <p>Este portfolio utiliza Google Analytics para conocer cuántas visitas recibe, qué páginas y proyectos se consultan, el tiempo de interacción y los clics en imágenes, contacto y el portfolio de Drive. Las cifras son aproximadas. La medición se limita a esta web: no permite ver lo que haces después en Drive o Gmail.</p>
        <p>Si aceptas, se carga el servicio de Google y se utilizan cookies de analítica como <code>_ga</code> y <code>_ga_…</code> para distinguir visitas, con una duración máxima de seis meses. La personalización publicitaria está desactivada. No se recoge el texto de formularios. Si rechazas, la analítica no se carga.</p>
        <p>La base de esta medición es tu consentimiento. El proveedor es Google Ireland Limited: recibe datos técnicos del navegador y dispositivo, identificadores de cookies y datos de navegación, y calcula estadísticas de procedencia y ubicación aproximada. Los datos individuales de usuarios y eventos se conservan durante dos meses; este límite no afecta a los informes agregados.</p>
        <p>Puedes cambiar tu elección aquí en cualquier momento. Al rechazar después de haber aceptado, se detiene la medición y se eliminan las cookies de analítica de esta web. Los datos ya enviados no se borran al cambiar esta preferencia.</p>
        <p>Tu elección se guarda en este navegador durante seis meses. <a href="https://policies.google.com/privacy?hl=es" target="_blank" rel="noreferrer">Consulta la política de privacidad de Google ↗</a> y <a href="https://policies.google.com/technologies/partner-sites?hl=es" target="_blank" rel="noreferrer">cómo utiliza Google los datos de esta web ↗</a>.</p>
        <p>Puedes solicitar el acceso, la rectificación o la supresión de tus datos y retirar tu consentimiento contactando con la responsable. También puedes presentar una reclamación ante la <a href="https://www.aepd.es/" target="_blank" rel="noreferrer">Agencia Española de Protección de Datos ↗</a>. La política de Google explica sus proveedores, transferencias internacionales y las garantías aplicables.</p>
        <div className="privacy-preference-box">
          <p className="privacy-status" role="status">{preferences.excluded?'Tus visitas están excluidas en este navegador.':preferences.consent==='granted'?'Has aceptado la analítica.':preferences.consent==='denied'?'Has rechazado la analítica.':'La analítica está desactivada hasta que elijas.'}</p>
          <label className="privacy-exclusion"><input type="checkbox" checked={preferences.excluded} onChange={exclude}/><span>No contar mis visitas en este navegador</span></label>
          <p className="privacy-help">Esta exclusión se recuerda solo aquí. Actívala también en el móvil o en los otros navegadores que utilices. Desactivarla no cambia tu elección de aceptar o rechazar la analítica.</p>
        </div>
      </div>
      <div className="privacy-actions privacy-dialog-actions"><button type="button" onClick={()=>choose('denied')}>Rechazar analítica</button><button type="button" onClick={()=>choose('granted')}>Aceptar analítica</button></div>
    </dialog>
  </>;
}
