import {useEffect,useRef,useState} from 'react';
import projects from './projects.json';
import detailAssets from './detail-assets.json';
import coverLayouts from './cover-layouts.json';
import resultLayouts from './result-layouts.json';
import ParallaxHome from './ParallaxHome.jsx';
const drive='https://drive.google.com/file/d/1Vvenp56weMOv1ttr9H92sPPOcrgmMfM0/view',mail='mailto:alexaromina30@gmail.com';
const image=name=>import.meta.env.BASE_URL+name+'?v=20261024-native';
const nameFonts=['Pinyon','Anton','Bodoni','Space Mono','UnifrakturMaguntia'];
function Name({animated=false}){
  const [face,setFace]=useState(0);
  useEffect(()=>{
    if(!animated)return;
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    let interval,cancelled=false;
    const start=()=>{clearInterval(interval);if(!reduced.matches)interval=setInterval(()=>setFace(n=>(n+1)%nameFonts.length),580)};
    Promise.allSettled(nameFonts.map(font=>document.fonts.load('400 100px "'+font+'"'))).then(()=>{if(!cancelled)start()});
    reduced.addEventListener('change',start);
    return()=>{cancelled=true;clearInterval(interval);reduced.removeEventListener('change',start)};
  },[animated]);
  return <span className={'wordmark '+(animated?'wordmark-animated':'wordmark-static')} data-face={animated?face:2} aria-label="Romina Pereyra"><span className="wordmark-text" key={animated?face:2} aria-hidden="true"><span>Romina</span>{' '}<span>Pereyra</span></span></span>;
}
function Card({project:p,priority=false,motion=false}){
  const [preview,setPreview]=useState(false);
  return <a className={'project-card '+(motion?'motion-card':'')} href={'#proyecto/'+p.id} aria-label={'Ver proyecto '+p.title+': '+p.subtitle} onMouseEnter={()=>motion&&setPreview(true)} onFocus={()=>motion&&setPreview(true)}>
    <div className="card-image"><img className="card-cover" src={image(p.thumbnail)} alt={p.title+' — '+p.subtitle} loading={priority?'eager':'lazy'} width="1000" height="1000"/>{motion&&preview&&<span className="motion-layer" aria-hidden="true">{[1,2,3].map((frame)=><img className={'motion-frame motion-frame-'+frame} key={frame} src={image(p.id+'-motion-'+frame+'.webp')} alt="" width="850" height="850"/>)}</span>}<span className="card-open">VER PROYECTO</span></div><div className="card-title"><h3>{p.title}</h3><span className="card-number">[{p.number}]</span></div><div className="card-meta"><span>{p.subtitle}</span><span>{p.category}</span></div>
  </a>;
}
function Home(){return <ParallaxHome Name={Name}/>}
function Projects(){const groups=[{title:'PRODUCTO Y MODELADO 3D',category:'Producto'},{title:'DISEÑO GRÁFICO Y PACKAGING',category:'Gráfico'},{title:'DISEÑO EDITORIAL',category:'Editorial'}];return <div className="projects-page page-pad"><div className="page-heading"><h1>Proyectos</h1><p>OBJETOS, IMÁGENES Y NARRATIVAS<br/>17 PROYECTOS / PORTFOLIO PERSONAL</p></div><nav className="category-nav" aria-label="Categorías de proyectos">{groups.map(g=><a href={'#proyectos/'+encodeURIComponent(g.category)} key={g.category}>{g.title}</a>)}</nav>{groups.map(g=><section className="project-group" id={'grupo-'+g.category} key={g.category}><div className="section-top"><h2>[{g.title}]</h2><span className="small-note">{String(projects.filter(p=>p.category===g.category).length).padStart(2,'0')} PROYECTOS</span></div><div className="project-grid archive-grid">{projects.filter(p=>p.category===g.category).map(p=><Card project={p} key={p.id}/>)}</div></section>)}<div className="archive-contact"><p>¿Tienes un proyecto en mente?</p><a className="text-link" href={mail}>HABLEMOS &gt;</a></div></div>}
function Info(){return <div className="info-page"><section className="about-intro page-pad"><p className="eyebrow">[UN POCO SOBRE MÍ]</p><h1><Name/></h1><div className="about-copy"><p>Mi nombre es Romina Pereyra Bonija.<br/>Soy diseñadora de producto, gráfica y editorial.</p><p>Aunque actualmente mi trabajo se centra sobre todo en el diseño de producto, también tengo formación en diseño gráfico y editorial, dos ámbitos que me interesan por su capacidad para construir imagen, narrativa y comunicación visual.</p><p>Me atraen especialmente los proyectos donde el diseño se relaciona con el entorno audiovisual y el cine. Trabajo de forma directa, combinando investigación, prototipado y prueba, cuidando siempre la materialidad, la funcionalidad y el detalle.</p><p className="about-location">Barcelona, España.</p></div></section><section className="cv-grid page-pad" aria-label="Currículum"><div><h2>[FORMACIÓN]</h2><p>ELISAVA, Barcelona<br/><span>Diseño e Ingeniería<br/>2023 — actualidad</span></p><p>IFP Antoni Algueró<br/><span>Diseño y Edición de Publicaciones<br/>Impresas y Multimedia / 2021 — 2023</span></p></div><div><h2>[EXPERIENCIA]</h2><p>Museu del Disseny — DHUB<br/><span>Investigación en diseño y archivo / 2025</span></p><p>OFFF Festival<br/><span>Apoyo logístico / 2024</span></p><p>Graó Tècnic<br/><span>Diseño gráfico e identidad / 2023</span></p><p>Editorial Ormobook<br/><span>Asistente de edición / 2022</span></p></div><div><h2>[HERRAMIENTAS]</h2><p>Illustrator · Photoshop · InDesign<br/>Rhinoceros 3D · Fusion 360<br/>Blender · AutoCAD · Figma</p><h2 className="cv-subhead">[IDIOMAS]</h2><p>Castellano — lengua materna<br/>Catalán — avanzado<br/>Inglés — elemental</p></div><div><h2>[CONTACTO]</h2><p><a href={mail}>alexaromina30@gmail.com</a></p><p>Barcelona, España</p><a className="underlined" href={drive} target="_blank" rel="noreferrer">Ver portfolio original &gt;</a></div></section><div className="workshop page-pad"><img src={image('romina-taller.webp')} alt="Romina trabajando en el taller de diseño" width="1626" height="1151" loading="lazy"/><div className="workshop-caption"><span>[DEL BOCETO A LA MATERIA]</span><span>INVESTIGAR / PROTOTIPAR / CREAR</span></div></div></div>}
function ResultsComposition({project,items,onImage}){
  const layout=resultLayouts[project.id];
  return <section className="fixed-results page-pad" aria-label={'Imágenes finales de '+project.title}><div className="fixed-result-layout" style={{'--layout-ratio':layout.width+'/'+layout.height}}>{layout.items.map((position,index)=>{
    const asset=items.find(item=>item.file===position.file)||items[index];
    const crop=position.image||{left:0,top:0,width:100,height:100};
    const aspect=(layout.width*position.width)/(layout.height*position.height);
    return <button type="button" className="gallery-button fixed-result-image" key={asset.file} data-wide={aspect>1.25} style={{clipPath:position.clipPath,'--image-left':position.left+'%','--image-top':position.top+'%','--image-width':position.width+'%','--image-height':position.height+'%','--frame-aspect':aspect,'--crop-left':crop.left+'%','--crop-top':crop.top+'%','--crop-width':crop.width+'%','--crop-height':crop.height+'%'}} onClick={()=>onImage(asset.file,project.title+' — resultado, imagen '+(index+1))} aria-label={'Ampliar imagen '+(index+1)+' de '+project.title}><img src={image(asset.file)} alt={asset.alt||project.title+', resultado final: imagen '+(index+1)} width={asset.width} height={asset.height} loading="lazy" decoding="async"/></button>;
  })}</div></section>;
}
function ImageCarousel({project,items,kind,onImage}){
  const [current,setCurrent]=useState(0);
  const [dragOffset,setDragOffset]=useState(0);
  const [dragging,setDragging]=useState(false);
  const sectionRef=useRef(null),gesture=useRef(null),suppressClickUntil=useRef(0);
  const isProcess=kind==='process',label=isProcess?'proceso':'resultado',id=kind+'-'+project.id;
  const focusActive=section=>requestAnimationFrame(()=>section.querySelector('.image-carousel-slide:not([aria-hidden="true"]) button')?.focus({preventScroll:true}));
  const showSlide=next=>{
    const section=sectionRef.current,focusedSlide=section?.contains(document.activeElement)&&document.activeElement.closest('.image-carousel-slide');
    setCurrent(next);
    if(focusedSlide)focusActive(section);
  };
  const move=direction=>showSlide(index=>(index+direction+items.length)%items.length);
  const keyDown=event=>{
    if(!['ArrowRight','ArrowLeft','Home','End'].includes(event.key)||items.length<2)return;
    event.preventDefault();
    if(event.key==='Home')showSlide(0);
    else if(event.key==='End')showSlide(items.length-1);
    else move(event.key==='ArrowRight'?1:-1);
  };
  const pointerDown=event=>{
    if(!event.isPrimary||event.button!==0||items.length<2)return;
    gesture.current={pointerId:event.pointerId,startX:event.clientX,startY:event.clientY,dragging:false};
  };
  const pointerMove=event=>{
    const start=gesture.current;
    if(!start||start.pointerId!==event.pointerId)return;
    const dx=event.clientX-start.startX,dy=event.clientY-start.startY;
    if(!start.dragging){
      if(Math.abs(dy)>10&&Math.abs(dy)>Math.abs(dx)){gesture.current=null;return}
      if(Math.abs(dx)<8||Math.abs(dx)<=Math.abs(dy))return;
      start.dragging=true;
      setDragging(true);
      event.currentTarget.setPointerCapture(event.pointerId);
    }
    event.preventDefault();
    setDragOffset(dx);
  };
  const endGesture=(event,cancelled=false)=>{
    const start=gesture.current;
    if(!start||start.pointerId!==event.pointerId)return;
    gesture.current=null;
    setDragOffset(0);
    setDragging(false);
    if(start.dragging){
      suppressClickUntil.current=performance.now()+350;
      const distance=event.clientX-start.startX;
      if(!cancelled&&Math.abs(distance)>Math.min(80,event.currentTarget.clientWidth*.12))move(distance<0?1:-1);
    }
    if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);
  };
  if(!items.length)return null;
  return <section ref={sectionRef} className={'image-carousel page-pad '+(isProcess?'process-section':'detail-gallery')} role="region" aria-roledescription="carrusel" aria-labelledby={id+'-title'} aria-describedby={id+'-help'} onKeyDown={keyDown}>
    <h2 className="visually-hidden" id={id+'-title'}>{isProcess?'Imágenes del proceso de ':'Imágenes finales de '}{project.title}</h2>
    <p className="visually-hidden" id={id+'-help'}>Usa las flechas para cambiar de imagen, arrastra horizontalmente o desliza con el dedo. Pulsa la imagen para ampliarla.</p>
    <div className={'image-carousel-window'+(dragging?' is-dragging':'')} id={id} onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={event=>endGesture(event)} onPointerCancel={event=>endGesture(event,true)} onLostPointerCapture={event=>endGesture(event,true)} onDragStart={event=>event.preventDefault()} onClickCapture={event=>{if(event.detail>0&&performance.now()<suppressClickUntil.current){event.preventDefault();event.stopPropagation()}}}>
      <div className="image-carousel-track" style={{transform:`translateX(calc(-${current*100}% + ${dragOffset}px))`}}>{items.map((asset,index)=><div className="image-carousel-slide" key={asset.file} aria-hidden={index!==current} role="group" aria-roledescription="diapositiva" aria-label={`${index+1} de ${items.length}`}><button type="button" className="gallery-button" tabIndex={index===current?0:-1} onClick={()=>onImage(asset.file,project.title+' — '+label+', imagen '+(index+1))} aria-label={'Ampliar imagen '+(index+1)+' del '+label+' de '+project.title}><img src={image(asset.file)} alt={asset.alt||project.title+', '+label+': imagen '+(index+1)} width={asset.width} height={asset.height} loading="lazy" draggable="false"/></button></div>)}</div>
    </div>
    <div className="image-carousel-controls"><button type="button" onClick={()=>move(-1)} aria-label={'Imagen anterior del '+label} aria-controls={id} disabled={items.length<2}>←</button><span className="image-carousel-count" aria-live="polite" aria-atomic="true"><span className="visually-hidden">{isProcess?'Proceso':'Resultado'}, imagen </span>{String(current+1).padStart(2,'0')} / {String(items.length).padStart(2,'0')}</span><button type="button" onClick={()=>move(1)} aria-label={'Imagen siguiente del '+label} aria-controls={id} disabled={items.length<2}>→</button></div>
  </section>;
}
function Project({project:p,onImage}){
  const i=projects.findIndex(x=>x.id===p.id),previous=projects[(i+projects.length-1)%projects.length],next=projects[(i+1)%projects.length];
  const assets=detailAssets[p.id],cover=coverLayouts[p.id];
  return <article className="detail-page">
    <header className="detail-hero"><img className="detail-cover" src={image(p.hero)} alt={p.title+', vista general del proyecto'} width="1600" height="1132" fetchPriority="high"/><h1 className="detail-title" style={cover.overlayStyle}><span className="visually-hidden">{p.title} — {p.subtitle}</span><img src={image(cover.titleImage)} alt="" aria-hidden="true" width={cover.width} height={cover.height}/></h1></header>
    <div className="detail-summary page-pad"><div><h2>{p.title}</h2><p className="detail-subtitle">{p.subtitle}</p><dl><dt>DISCIPLINA</dt><dd>{p.category}</dd><dt>AUTORÍA</dt><dd>Romina Pereyra</dd><dt>CONTEXTO</dt><dd>Proyecto de portfolio / formación en diseño</dd></dl></div><p className="project-description">{p.description}</p></div>
    <ResultsComposition project={p} items={assets.results} onImage={onImage}/>
    <ImageCarousel key={p.id+'-process'} project={p} items={assets.process} kind="process" onImage={onImage}/>
    <nav className="project-pagination page-pad" aria-label="Navegación entre proyectos"><a href={'#proyecto/'+previous.id}><span>&lt; ANTERIOR</span><strong>{previous.title}</strong></a><a className="pagination-all" href="#proyectos">TODOS LOS PROYECTOS</a><a href={'#proyecto/'+next.id}><span>SIGUIENTE &gt;</span><strong>{next.title}</strong></a></nav>
  </article>;
}
function Footer(){return <footer className="footer page-pad"><a href="#inicio">ROMINA PEREYRA © {new Date().getFullYear()}</a><span>BARCELONA, ESPAÑA</span><a href={mail}>DISEÑEMOS ALGO JUNTOS &gt;</a></footer>}
export function App(){const[route,setRoute]=useState(location.hash.slice(1)||'inicio'),[zoom,setZoom]=useState(null);const dialog=useRef(null),main=useRef(null);useEffect(()=>{const handle=()=>setRoute(location.hash.slice(1)||'inicio');addEventListener('hashchange',handle);return()=>removeEventListener('hashchange',handle)},[]);const project=projects.find(p=>route==='proyecto/'+p.id),isProjects=route.startsWith('proyectos'),isInfo=route==='info';useEffect(()=>{document.title=project?project.title+' — Romina Pereyra':isInfo?'Sobre mí — Romina Pereyra':isProjects?'Proyectos — Romina Pereyra':'Romina Pereyra — Portfolio';if(route.startsWith('proyectos/'))requestAnimationFrame(()=>document.getElementById('grupo-'+decodeURIComponent(route.split('/')[1]))?.scrollIntoView({behavior:'instant'}));else window.scrollTo({top:0,behavior:'instant'});main.current?.focus({preventScroll:true})},[route]);useEffect(()=>{if(zoom){dialog.current?.showModal();document.body.style.overflow='hidden'}else{dialog.current?.close();document.body.style.overflow=''}return()=>{document.body.style.overflow=''}},[zoom]);return <div className={"site-shell "+(!project&&!isProjects&&!isInfo?"home-shell":"")}><a className="skip-link" href="#main-content" onClick={e=>{e.preventDefault();main.current?.focus()}}>Saltar al contenido</a><header className="site-header"><a href="#inicio" aria-current={!isProjects&&!isInfo&&!project?'page':undefined}>INICIO</a><nav aria-label="Navegación principal"><a href="#proyectos" aria-current={isProjects||project?'page':undefined}>PROYECTOS</a><a href="#info" aria-current={isInfo?'page':undefined}>INFO</a><a href={mail}>CONTACTO</a></nav></header><main ref={main} id="main-content" tabIndex="-1">{project?<Project project={project} onImage={(src,alt)=>setZoom({src,alt})}/>:isInfo?<Info/>:isProjects?<Projects/>:<Home/>}</main><Footer/><dialog className="lightbox" ref={dialog} aria-label="Imagen ampliada" onCancel={()=>setZoom(null)} onClick={e=>{if(e.target===dialog.current)setZoom(null)}}><button className="lightbox-close" onClick={()=>setZoom(null)}>CERRAR ×</button>{zoom&&<img src={image(zoom.src)} alt={zoom.alt}/>}</dialog></div>}


