import {useEffect,useRef,useState} from 'react';
import projects from './projects.json';
import detailAssets from './detail-assets.json';
import resultLayouts from './result-layouts.json';
import ParallaxHome from './ParallaxHome.jsx';
import {contactHref as mail} from './contact.js';
import {projectPreview} from './project-previews.js';
import useScrollReveal from './useScrollReveal.js';
import CoverTitle from './CoverTitle.jsx';
import AboutPage from './AboutPage.jsx';
import AnalyticsPrivacy from './AnalyticsPrivacy.jsx';
import usePortfolioAnalytics,{trackAnalyticsEvent} from './usePortfolioAnalytics.js';
const drive='https://drive.google.com/file/d/1Vvenp56weMOv1ttr9H92sPPOcrgmMfM0/view';
const image=name=>import.meta.env.BASE_URL+name+'?v=20261024-native';
function Name({calligraphy=false,entrance=false}){
  const [ready,setReady]=useState(!entrance);
  useEffect(()=>{
    if(!entrance)return;
    let cancelled=false;
    const show=()=>{if(!cancelled)setReady(true)};
    if(document.fonts)document.fonts.load('400 100px Pinyon').then(show,show);else show();
    return()=>{cancelled=true};
  },[entrance]);
  return <span className={'wordmark wordmark-static'+(calligraphy?' wordmark-calligraphy':'')+(entrance?' wordmark-entrance':'')} data-face={calligraphy?0:2} data-ready={ready} aria-label="Romina Pereyra"><span className="wordmark-text" aria-hidden="true"><span>Romina</span>{' '}<span>Pereyra</span></span></span>;
}
function Card({project:p,priority=false,motion=false}){
  const [preview,setPreview]=useState(false);
  const cover=projectPreview(p);
  return <a className={'project-card '+(motion?'motion-card':'')} data-scroll-reveal="" href={'#proyecto/'+p.id} aria-label={'Ver proyecto '+p.title+': '+p.subtitle} onMouseEnter={()=>motion&&setPreview(true)} onFocus={()=>motion&&setPreview(true)}><div className="scroll-reveal-content">
    <div className="card-image"><img className="card-cover" src={image(cover.file)} alt={p.title+' — '+p.subtitle} loading={priority?'eager':'lazy'} width={cover.width} height={cover.height}/>{motion&&preview&&<span className="motion-layer" aria-hidden="true">{[1,2,3].map((frame)=><img className={'motion-frame motion-frame-'+frame} key={frame} src={image(p.id+'-motion-'+frame+'.webp')} alt="" width="850" height="850"/>)}</span>}<span className="card-open">VER PROYECTO</span></div><div className="card-title"><h3>{p.title}</h3><span className="card-number">[{p.number}]</span></div><div className="card-meta"><span>{p.subtitle}</span><span>{p.category}</span></div>
  </div></a>;
}
function Home(){return <ParallaxHome Name={Name}/>}
function Projects(){const archive=useRef(null);useScrollReveal(archive);const groups=[{title:'PRODUCTO Y MODELADO 3D',category:'Producto'},{title:'DISEÑO GRÁFICO Y PACKAGING',category:'Gráfico'},{title:'DISEÑO EDITORIAL',category:'Editorial'}];return <div ref={archive} className="projects-page page-pad"><div className="page-heading"><h1 data-scroll-reveal="" data-reveal-kind="heading"><span className="scroll-reveal-content">Proyectos</span></h1><p>OBJETOS, IMÁGENES Y NARRATIVAS<br/>17 PROYECTOS / PORTFOLIO PERSONAL</p></div><nav className="category-nav" aria-label="Categorías de proyectos">{groups.map(g=><a href={'#proyectos/'+encodeURIComponent(g.category)} key={g.category}>{g.title}</a>)}</nav>{groups.map(g=><section className="project-group" id={'grupo-'+g.category} key={g.category}><div className="section-top"><h2>[{g.title}]</h2><span className="small-note">{String(projects.filter(p=>p.category===g.category).length).padStart(2,'0')} PROYECTOS</span></div><div className="project-grid archive-grid">{projects.filter(p=>p.category===g.category).map(p=><Card project={p} key={p.id}/>)}</div></section>)}<div className="archive-contact"><p>¿Tienes un proyecto en mente?</p><a className="text-link" href={mail} target="_blank" rel="noreferrer">HABLEMOS &gt;</a></div></div>}
function Info(){return <AboutPage Name={Name} contactHref={mail} portfolioUrl={drive}/>;}
function PhotoGallery({project,items,kind='results',onImage}){
  const isProcess=kind==='process',rows=[];
  if(isProcess){
    for(let start=0;start<items.length;){const count=items.length-start===4?2:Math.min(3,items.length-start);rows.push({items:items.slice(start,start+count).map((asset,index)=>({asset,index:start+index}))});start+=count}
  }else{
    resultLayouts[project.id].items.forEach(position=>{
      const asset=items.find(item=>item.file===position.file);
      if(!asset)return;
      let row=rows.find(candidate=>Math.abs(candidate.top-position.top)<2);
      if(!row){row={top:position.top,items:[]};rows.push(row)}
      row.items.push({asset,left:position.left,index:items.indexOf(asset)});
    });
    rows.sort((a,b)=>a.top-b.top);
    rows.forEach(row=>row.items.sort((a,b)=>a.left-b.left));
  }
  const label=isProcess?'proceso':'resultado';
  return <section className={'fixed-results page-pad'+(isProcess?' process-gallery':'')} data-gallery-kind={kind} aria-label={(isProcess?'Proceso de ':'Imágenes finales de ')+project.title}>
    {isProcess&&<header className="gallery-intro"><h2 data-scroll-reveal="" data-reveal-kind="heading"><span className="scroll-reveal-content">Proceso</span></h2><p>{project.process}</p></header>}
    <div className="fixed-result-layout">{rows.map((row,rowIndex)=><div className="fixed-result-row" key={rowIndex} style={{'--row-columns':row.items.map(({asset})=>(asset.width/asset.height)+'fr').join(' ')}}>{row.items.map(({asset,index})=><button type="button" className="gallery-button fixed-result-image" key={asset.file} data-scroll-reveal="" data-wide={asset.width/asset.height>1.25} onClick={()=>{trackAnalyticsEvent('image_open',{project_id:project.id,gallery_kind:kind,image_index:index+1});onImage(asset.file,project.title+' — '+label+', imagen '+(index+1))}} aria-label={'Ampliar imagen '+(index+1)+' del '+label+' de '+project.title}><span className="scroll-reveal-content"><img src={image(asset.file)} alt={asset.alt||project.title+', '+label+': imagen '+(index+1)} width={asset.width} height={asset.height} loading="lazy" decoding="async"/></span></button>)}</div>)}</div>
  </section>;
}
function Project({project:p,onImage}){
  const detail=useRef(null);
  useScrollReveal(detail,p.id);
  const i=projects.findIndex(x=>x.id===p.id),previous=projects[(i+projects.length-1)%projects.length],next=projects[(i+1)%projects.length];
  const assets=detailAssets[p.id];
  return <article ref={detail} className="detail-page">
    <header className="detail-hero"><img className="detail-cover" src={image(p.hero)} alt={p.title+', vista general del proyecto'} width="1600" height="1132" fetchPriority="high"/><CoverTitle key={p.id} project={p}/></header>
    <div className="detail-summary page-pad"><div><h2 data-scroll-reveal="" data-reveal-kind="heading"><span className="scroll-reveal-content">{p.title}</span></h2><p className="detail-subtitle" data-scroll-reveal="" data-reveal-kind="heading"><span className="scroll-reveal-content">{p.subtitle}</span></p><dl><dt>DISCIPLINA</dt><dd>{p.category}</dd><dt>AUTORÍA</dt><dd>Romina Pereyra</dd><dt>CONTEXTO</dt><dd>Proyecto de portfolio / formación en diseño</dd></dl></div><p className="project-description">{p.description}</p></div>
    <PhotoGallery project={p} items={assets.results} onImage={onImage}/>
    <PhotoGallery project={p} items={assets.process} kind="process" onImage={onImage}/>
    <nav className="project-pagination page-pad" aria-label="Navegación entre proyectos"><a href={'#proyecto/'+previous.id}><span>&lt; ANTERIOR</span><strong>{previous.title}</strong></a><a className="pagination-all" href="#proyectos">TODOS LOS PROYECTOS</a><a href={'#proyecto/'+next.id}><span>SIGUIENTE &gt;</span><strong>{next.title}</strong></a></nav>
  </article>;
}
function Footer(){return <footer className="footer page-pad"><a href="#inicio">ROMINA PEREYRA © {new Date().getFullYear()}</a><span>BARCELONA, ESPAÑA</span><a href={mail} target="_blank" rel="noreferrer">DISEÑEMOS ALGO JUNTOS &gt;</a></footer>}
export function App(){const[route,setRoute]=useState(location.hash.slice(1)||'inicio'),[zoom,setZoom]=useState(null);const dialog=useRef(null),main=useRef(null);useEffect(()=>{const handle=()=>setRoute(location.hash.slice(1)||'inicio');addEventListener('hashchange',handle);return()=>removeEventListener('hashchange',handle)},[]);const project=projects.find(p=>route==='proyecto/'+p.id),isProjects=route.startsWith('proyectos'),isInfo=route==='info';const screenTitle=project?project.title+' — Romina Pereyra':isInfo?'Sobre mí — Romina Pereyra':isProjects?'Proyectos — Romina Pereyra':'Romina Pereyra — Portfolio';const onAnalyticsPreference=usePortfolioAnalytics({route:project?'proyecto/'+project.id:isInfo?'info':isProjects?'proyectos':'inicio',title:screenTitle,projectId:project?.id});useEffect(()=>{document.title=project?project.title+' — Romina Pereyra':isInfo?'Sobre mí — Romina Pereyra':isProjects?'Proyectos — Romina Pereyra':'Romina Pereyra — Portfolio';if(route.startsWith('proyectos/'))requestAnimationFrame(()=>document.getElementById('grupo-'+decodeURIComponent(route.split('/')[1]))?.scrollIntoView({behavior:'instant'}));else window.scrollTo({top:0,behavior:'instant'});main.current?.focus({preventScroll:true})},[route]);useEffect(()=>{if(zoom){dialog.current?.showModal();document.body.style.overflow='hidden'}else{dialog.current?.close();document.body.style.overflow=''}return()=>{document.body.style.overflow=''}},[zoom]);return <div className={"site-shell "+(!project&&!isProjects&&!isInfo?"home-shell":"")}><a className="skip-link" href="#main-content" onClick={e=>{e.preventDefault();main.current?.focus()}}>Saltar al contenido</a><header className="site-header"><a href="#inicio" aria-current={!isProjects&&!isInfo&&!project?'page':undefined}>INICIO</a><nav aria-label="Navegación principal"><a href="#proyectos" aria-current={isProjects||project?'page':undefined}>PROYECTOS</a><a href="#info" aria-current={isInfo?'page':undefined}>INFO</a><a href={mail} target="_blank" rel="noreferrer">CONTACTO</a></nav></header><main ref={main} id="main-content" tabIndex="-1">{project?<Project key={project.id} project={project} onImage={(src,alt)=>setZoom({src,alt})}/>:isInfo?<Info/>:isProjects?<Projects/>:<Home/>}</main><Footer/><div className="privacy-controls page-pad"><AnalyticsPrivacy onPreferenceChange={onAnalyticsPreference}/></div><dialog className="lightbox" ref={dialog} aria-label="Imagen ampliada" onCancel={()=>setZoom(null)} onClick={e=>{if(e.target===dialog.current)setZoom(null)}}><button className="lightbox-close" onClick={()=>setZoom(null)}>CERRAR ×</button>{zoom&&<img src={image(zoom.src)} alt={zoom.alt}/>}</dialog></div>}


