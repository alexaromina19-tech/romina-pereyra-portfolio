import detailAssets from './detail-assets.json';
const fullCoverSizes={grease:[2441,1726],'switch-seat':[1862,1317],'silla-05':[3002,2123],'red-trackwear':[2629,1859]};
const fullViews={kubik:0,nightfall:4,'kota-yamaji':5,marshall:2,'chips-ahoy':1,'time-out':5,trizart:1,mescladis:0,'anillos-caramelo':0,aurea:1,trofeo:1,moonlit:1,'amics-rambla':4};
export function projectPreview(project){
  const cover=fullCoverSizes[project.id];
  return cover?{file:project.hero,width:cover[0],height:cover[1]}:detailAssets[project.id].results[fullViews[project.id]||0];
}
