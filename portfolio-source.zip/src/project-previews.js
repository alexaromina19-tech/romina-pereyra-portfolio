import detailAssets from './detail-assets.json';
import focused from './home-focus-views.json';
import archive from './archive-previews.json';
const fullViews={kubik:0,nightfall:4,'kota-yamaji':5,marshall:2,'chips-ahoy':1,'time-out':5,trizart:1,mescladis:4,'anillos-caramelo':0,trofeo:1,moonlit:1,'amics-rambla':2};
export function projectPreview(project,variant='archive'){
  if(variant==='archive')return archive[project.id];
  if(variant==='hero'&&project.id==='mescladis')return detailAssets.mescladis.results[2];
  const view=focused[project.id];
  return view?{file:view.source,width:view.width,height:view.height,crop:view.css}:detailAssets[project.id].results[fullViews[project.id]||0];
}
