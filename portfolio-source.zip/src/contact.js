export const contactHref='https://mail.google.com/mail/?view=cm&fs=1&to=alexaromina30%40gmail.com';
